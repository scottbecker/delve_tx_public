import re

AMINO_ACID_TO_DNA = {}
from Bio import Entrez
from Bio.Seq import Seq
from Bio.Data import CodonTable
from Bio import SeqIO, SeqRecord
import math
import logging
import xml.etree.ElementTree as etree 
from xml.etree.ElementTree import Element
import requests
Entrez.email = "robot@heatseekinglab.com"
min_pro_len = 100

def custom_floor(x, base=3):
    return int(base * math.floor(float(x)/base))


def get_gene_cononical_sequences(gene_name):
    """
    Returns the ncbi identifiers for the cDNA and amino acid sequence
    """
    r = requests.get('http://www.uniprot.org/uniprot/?query=gene:%s AND reviewed:yes AND organism:"Homo sapiens (Human) [9606]"&sort=score&format=json'%gene_name)
    gene_entry_id = r.json()[0]['id']
    r = requests.get('http://www.uniprot.org/uniprot/%s.xml'%gene_entry_id)
    entry_data_tree = etree.fromstring(r.text)
    
    gene_sequence_pairs = []
    
    for ref_seq_node in entry_data_tree.findall('.//{http://uniprot.org/uniprot}dbReference[@type="RefSeq"]'):
        assert isinstance(ref_seq_node,Element)
        protein_seq_id = ref_seq_node.attrib['id']
        dna_seq_node = ref_seq_node.find('.//{http://uniprot.org/uniprot}property[@type="nucleotide sequence ID"]')
        dna_seq_id = dna_seq_node.attrib['value']
        gene_sequence_pairs.append([protein_seq_id,dna_seq_id])
        
    return gene_sequence_pairs


def find_orfs_with_trans(seq, trans_table='Standard', min_protein_length=100):
    """
    
    Returns a set of tuples. Each tuple represents an ORF
    
    The orf tuple is of the format (start,end,strand_type,orf_protein_sequence)
    """
    answer = []
    seq_len = len(seq)
    for strand, nuc in [(+1, seq), (-1, seq.reverse_complement())]:
        for frame in range(3):
            trans = str(nuc[frame:custom_floor(len(seq)-frame,3)+frame].translate(trans_table))
            trans_len = len(trans)
            
            aa_start = 0
            aa_end = 0
            while aa_start < trans_len:
                #start at the first Methionine
                try:
                    aa_start = trans.index('M',aa_start)
                except ValueError:
                    #we didn't find a Methionine in the remaining protein
                    break
                aa_end = trans.find("*", aa_start)
                if aa_end == -1:
                    aa_end = trans_len
                if aa_end-aa_start >= min_protein_length:
                    if strand == 1:
                        start = frame+aa_start*3
                        end = min(seq_len,frame+aa_end*3+3)
                    else:
                        start = seq_len-frame-aa_end*3-3
                        end = seq_len-frame-aa_start*3
                    answer.append((start, end, strand,
                                   trans[aa_start:aa_end]))
                aa_start = aa_end+1
    answer.sort()
    return answer

def gene_name_to_dna_sequences(gene_name, organism='Homo sapiens'):
    """
    Returns a gene's reference DNA sequences (cut from the mRNA sequence)
    Includes the stop codon DNA sequence
    
    """    
    
    matching_dna_sequences = []
    
    for protein_seq_id, dna_seq_id in get_gene_cononical_sequences(gene_name):
        
        
        #get the mRNA based DNA sequence
        logging.debug("using nucleotide id %s as cononical"%dna_seq_id)
        handle = Entrez.efetch(db="nucleotide", rettype="fasta", retmode="text", id=dna_seq_id)
        seq_record = SeqIO.read(handle, "fasta")
        
        #source assist helper
        if 0:
            assert isinstance(seq_record,SeqRecord.SeqRecord)
            
        handle.close()
        
        dna_seq = seq_record.seq
        
        #source assist helper
        
        assert isinstance(dna_seq,Seq)
        
    
        orf_list = find_orfs_with_trans(dna_seq)
        
        #retrieve the first result
        
        #retrieve the amino acid sequence
        handle = Entrez.esearch(db="protein", term='"%s"[Orgn] AND %s[Gene]'%(organism,gene_name))
        record = Entrez.read(handle) 
    
        logging.debug("using protein id %s as cononical"%protein_seq_id)    
        handle = Entrez.efetch(db="protein", rettype="fasta", retmode="text", id=protein_seq_id)
        seq_record = SeqIO.read(handle, "fasta")    
        
        protein_sequence = seq_record.seq
        
        #find the amino acid sequence in the DNA sequence
        
        matching_orf = None
        
        for orf in orf_list:
            if str(orf[3]) == str(protein_sequence):
                matching_orf = orf
                break
        
        if not matching_orf:
            raise Exception("No matching ORF found for protein: %s \n in orf list %s \n for dna seq %s "%(protein_sequence,str(orf_list),dna_seq))
            
        matching_dna_sequences.append(dna_seq[matching_orf[0]:matching_orf[1]])

    return matching_dna_sequences
    

def string_char_diff(stra,strb):
    assert len(stra) == len(strb), 'Strings must be equal length'
    char_changes=[]
    for i in range(0,len(stra)):
        if stra[i]!=strb[i]:
            char_changes.append([stra[i],strb[i]])
            
    return char_changes


def convert_aa_change_to_dna_change(gene_dna_sequence, 
                                    amino_acid_change_code):
    """
    Converts an amino acid change code (e.g. A459T) into a DNA base pair change code (assumes only a single codon has been changed).
    
    gene_dna_sequence must be the coding region of the DNA that is converted into RNA
    
    It raises an exception if no dna code can be deciphered 
    
    """
    assert isinstance(gene_dna_sequence,Seq)
    
    #remove all numbers from the change code
    #get the zero indexed amino acid code
    aa_index = int(re.sub(r'\D', '', amino_acid_change_code))-1
    aa_letters = re.sub(r'\d', '', amino_acid_change_code).upper()
    from_aa = aa_letters[0]
    to_aa = aa_letters[1]
    
    #find the potential source
    #check that the from agrees with the sequence
    if gene_dna_sequence.translate()[aa_index] != from_aa:
        #'incorrect "from" amino acid found'
        return None
    
    #get the dna sequence for the from aa
    from_dna_code = gene_dna_sequence[aa_index*3:aa_index*3+3]
    
    #find the set of amino acids that are 1 change away in the set of allowed base pairs 
    codon_table = CodonTable.unambiguous_dna_by_name['Standard']
    assert isinstance(codon_table,CodonTable.CodonTable)
    
    to_codons = [dna for dna,protein_code in codon_table.forward_table.items() if protein_code==to_aa]
    
    to_dna_code = None
    final_char_changes = None
    for to_codon in to_codons:
        char_changes = string_char_diff(from_dna_code,to_codon)
        if len(char_changes)==1:
            to_dna_code = to_codon
            final_char_changes = char_changes[0]
            break
            
    if not to_dna_code:
        #"to codon not found"
        return None
    
    logging.debug("From DNA Code: %s"%from_dna_code)
    logging.debug("To DNA Code: %s"%to_dna_code)
    
    return final_char_changes
    

if __name__=='__main__':

    logging.basicConfig(level=logging.WARN)
    
    mutation_gene_pairs = [
        #['KRAS',['A146T','G12D','G12S','G12V','G12R']],
        ['TGFBR2',['D524Y']],
        
    ]

    for gene_name, mutations in mutation_gene_pairs:
        print("-"*(50))
        gene_dna_seqs = gene_name_to_dna_sequences(gene_name)
        for mutation in mutations:
            dna_code_found = False
            for gene_dna in gene_dna_seqs:
                dna_code_change = convert_aa_change_to_dna_change(gene_dna, mutation)
                if not dna_code_change: continue
                dna_code_found = True
                print("%s, %s: %s"%(gene_name,mutation,str(dna_code_change)))
                
            assert dna_code_found