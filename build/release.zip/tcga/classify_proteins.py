import sys
import csv
import json
import logging
import xml.etree.ElementTree as etree 
from xml.etree.ElementTree import Element
import requests

def get_locations_of_gene_product(gene_name):
    """
    Returns the ncbi identifiers for the cDNA and amino acid sequence
    """
    try:
        r = requests.get('http://www.uniprot.org/uniprot/?query=gene:%s AND reviewed:yes AND organism:"Homo sapiens (Human) [9606]"&sort=score&format=json'%gene_name)
        if not r.text:
            return []
        gene_entry_id = r.json()[0]['id']
        r = requests.get('http://www.uniprot.org/uniprot/%s.xml'%gene_entry_id)
    except:
        logging.exception('gene failed to get results from uniprot: %s'%gene_name)
        return []
    
    entry_data_tree = etree.fromstring(r.text)
    
    locations = []
    
    for location in entry_data_tree.findall('.//{http://uniprot.org/uniprot}subcellularLocation/{http://uniprot.org/uniprot}location'):
        assert isinstance(location,Element)
        locations.append(location.text)
        
    return locations    

def save(gene_location_mapping):
    outfile = open('gene_location_mapping.json','w')
    outfile.write(json.dumps(gene_location_mapping,indent=True,sort_keys=True))
    outfile.close()
    

if __name__ == "__main__":
    
    logging.basicConfig(level=logging.WARN)
    
    #get the list of unique proteins
    gene_names = set()
    with open(sys.argv[1]) as tsv:
        for line in csv.reader(tsv, dialect="excel-tab"):
            gene_names.add(line[0])
    
    gene_location_mapping = {}
    
    i = 0
    for gene_name in gene_names:
        i+=1
        locations = get_locations_of_gene_product(gene_name)
        logging.debug("%s: %s"%(gene_name,str(locations)))
        gene_location_mapping[gene_name] = locations
        
        if i%20==0:
            save(gene_location_mapping)
            
        
    save(gene_location_mapping)
