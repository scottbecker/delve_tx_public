import sys
import csv
import json
import logging
import xml.etree.ElementTree as etree 
from xml.etree.ElementTree import Element
import requests

"""
This will determine the upper bound on number of tumor samples that have at least one mutation that is exposed outside the cell.

This could contain false positives because the location of the mutation might be on the intra-cellular side of the 
"""

IS_MEMBRANE_GENE_CACHE = {}

def prime_is_membrane_cache():
    global IS_MEMBRANE_GENE_CACHE
    
    gene_location_mapping = json.loads(open('gene_location_mapping.json','r').read())
    
    for gene_name, locations in gene_location_mapping.items():
        if 'Membrane' in locations or 'Cell membrane' in locations:
            IS_MEMBRANE_GENE_CACHE[gene_name] = True

def is_membrane_gene(gene_name):
    global IS_MEMBRANE_GENE_CACHE
    
    if not IS_MEMBRANE_GENE_CACHE:
        prime_is_membrane_cache()
        
    return gene_name in IS_MEMBRANE_GENE_CACHE

if __name__ == "__main__":
    
    logging.basicConfig(level=logging.DEBUG)
        
    
    
    #get the list of unique proteins
    all_samples = set()
    membrane_mutation_samples = set() 
    with open(sys.argv[1]) as tsv:
        for line in csv.DictReader(tsv, dialect="excel-tab"):
            all_samples.add(line['Tumor_Sample_Barcode'])
            
            if is_membrane_gene(line['Hugo_Symbol']):
                membrane_mutation_samples.add(line['Tumor_Sample_Barcode'])
                
                
    membrane_count = len(membrane_mutation_samples)
    membrane_percent = 1.0*membrane_count / len(all_samples)*100
    
    print('There are %s membrane protein mutation containing samples, %s%%'%(membrane_count,membrane_percent))


