from __future__ import print_function
import sys
from Bio import SeqIO
from Bio import pairwise2

from Bio.SeqRecord import SeqRecord
handle = open(sys.argv[1], "rU")
seq1 = list(SeqIO.parse(handle, "fasta"))[0]
handle.close()

handle = open(sys.argv[2], "rU")
seq2 = list(SeqIO.parse(handle, "fasta"))[0]
handle.close()

assert isinstance(seq1, SeqRecord)
assert isinstance(seq2, SeqRecord)

print(pairwise2.align.globalxx(seq1.seq, seq2.seq))