from transcriptic_tools.utils import initialize_config
import requests
import json

from transcriptic_tools.inventory import get_transcriptic_inventory



def get_dict_subset(d,keys):
    return dict((k, d[k]) for k in keys)

def get_resource_info(resource_id,headers=None):
    
    initialize_config()
    
    from transcriptic_tools.utils import TSC_HEADERS
    
    headers = headers if headers else TSC_HEADERS
    
    def _resource_url(resource_id):
            return 'https://secure.transcriptic.com/api/resources/{}?format=json'.format(resource_id)

    response = requests.get(_resource_url(resource_id), headers=headers, verify=False)
    response.raise_for_status()

    return response.json()   
    
    
transcriptic_inventory = get_transcriptic_inventory(include_lowercase=False)  

#make_it_unique_by_resource_id  
 

unique_resource_ids = set()
unique_resource_ids.update(transcriptic_inventory.values())
   
all_inventory = []

for resource_id in unique_resource_ids:
    
    if not resource_id.startswith('rs'):
        #ignore kits
        continue
    
    new_resource = get_dict_subset(get_resource_info(resource_id)['data']['attributes'],['name','kind',
                                                                                         'sensitivities','storage_condition',
                                                                                         'properties','description'])
    new_resource['transcriptic_id'] = resource_id

    all_inventory.append(new_resource)

    
import pprint
print "TRANSCRIPTIC_RESOURCES = "+pprint.pformat(all_inventory, indent=4)


