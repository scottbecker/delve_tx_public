from __future__ import print_function
import datetime
from transcriptic_tools.utils import ul, ml, copy_cell_line_name, get_cell_line_name, get_well_dead_volume
from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container
from transcriptic_tools.enums import Reagent

FLOW_TEST_SAMPLE_VOLUME = ml(0.5)

#this should be changed to ml(1) for a new cell type
FLOW_NEG_CONTROL_VOLUME = {
    'vero': ul(100),
    'cfpac-1':ul(100),
    'unknown': ml(1)
    }

VOLTAGE_RANGES = {
    'vero':{
        'FSC':250,
        'SSC':280,
    },
    'cfpac-1':{
        'FSC':235,
        'SSC':275,
    }    
}

def trypsonize_plate(p,cell_plate,destination_well=None,
                     wells=None):
    """
    
    Removes cells from cell_plate and puts them into destination well
    
    """
    
    assert isinstance(cell_plate,Container)
    assert isinstance(p,Protocol)
    
    #only trypsonize wells with non-zero volume
    if wells:
        all_wells = wells
    else:
        all_wells = [well for well in cell_plate.all_wells() if well.volume > ul(0)]
        
    p.trash_max_volume(all_wells)
    
    #repeat these steps three times to free up cells
    for x in range(0,2):
        p.provision_by_name(Reagent.pbs, all_wells, ml(3))
        p.trash_max_volume(all_wells)
        
    p.provision_by_name(Reagent.trypsin_edta, all_wells, ml(0.5), pre_warm_minutes=5)
    add_trypsin_instruction_index  = p.get_instruction_index()
    
    #we may want to try 15minutes here
    p.incubate(cell_plate, 'warm_37', '10:minute', co2=0)
    
    p.provision_by_name(Reagent.culture_medium, all_wells, ml(1),
                        mix_after=True)
    add_culture_medium_instruction_index  = p.get_instruction_index()
    
    p.add_time_constraint({"mark": add_trypsin_instruction_index, "state": "end"},
                          {"mark": add_culture_medium_instruction_index, "state": "end"},
                          "11:minute")
    
    if destination_well:
        #likely redundant but we are playing it safe
        copy_cell_line_name(cell_plate,destination_well)
        #carryover is ok because we are going to discard cell_plate when we are done so there
        #is no risk of contamination
        #mixing is to remove clumps of cells
        p.consolidate(all_wells, destination_well, ml(1.5),
                      allow_carryover=True,
                      mix_after=True) 
        
        #all cells are now removed from the plate
        cell_plate.discard()
        
    
        

def cell_maintenance(p, cell_plates, incubate_hours=3*24, flow_analyze=True):   
    #@TODO: update this to handle saving information in our database for the post-flow step to run
    #e.g. number of plates to make.  We may need to have a queue in a web accessible database
    assert isinstance(p, Protocol)
    if incubate_hours<0:
        raise ValueError('unable to incubate for negative hours: %s'%incubate_hours)
    
    if incubate_hours>5*24:
        raise ValueError('We cannot incubate for more than 5 days, otherwise colonies form.'+\
                         'You requested %s hours'%incubate_hours)
    
    
    if not isinstance(cell_plates, list):
        cell_plates = [cell_plates]    
    
    if incubate_hours>1:
        for cell_plate in cell_plates:
            for x in range(0,int(incubate_hours/24)):
                p.incubate(cell_plate, 'warm_37', '24:hour')
                p.image_plate(cell_plate,'top','confluence_contamination_check_%s_%s'%(cell_plate.name,x))
                
            #in case we aren't incubating for a multiple of 24 hours
            if incubate_hours%24:
                p.incubate(cell_plate, 'warm_37', '%s:hour'%(incubate_hours%24))
                
    else:
        for cell_plate in cell_plates:
            p.incubate(cell_plate, 'warm_37', '%s:minute'%(incubate_hours*60)) 
    
    if not flow_analyze:
        return cell_plates
    else:
        #provision a 24-deep to hold the 10ml
        #@TODO: We should re-use 24-deep plates (new well each time) at this step to save $
    
        cell_line_name = get_cell_line_name(cell_plates)
        aggregate_cells_well = p.get_10ml_well('trypsonized_%s_cells'%cell_line_name)

        cell_plate = cell_plates[0]
        trypsonize_plate(p, cell_plate, aggregate_cells_well)
        
    
        #we use a separate tube to avoid contamination
        flow_well = p.ref("flow_analysis_tube", cont_type="micro-2.0", discard=True).well(0)
         
        #@TODO: adjust these to use less volume once we know our voltage ranges
        
        flow_neg_control_volume = FLOW_NEG_CONTROL_VOLUME[cell_line_name] if cell_line_name in FLOW_NEG_CONTROL_VOLUME else FLOW_NEG_CONTROL_VOLUME['unknown']
        
        p.transfer(aggregate_cells_well, flow_well, FLOW_TEST_SAMPLE_VOLUME + flow_neg_control_volume + get_well_dead_volume(flow_well),
                   #mixing to break up cells
                   mix_after=True,repetitions=10)
        
        ##discard the cell plate
        ##turned off for now in-case we make any mistakes, eventually turn on
        #cell_plate.discard()
        
        fsc_voltage_low = 250
        fsc_voltage_high = 450
        ssc_voltage_low = 250
        ssc_voltage_high = 450
        
        if cell_line_name in VOLTAGE_RANGES:
            fsc_voltage_low = VOLTAGE_RANGES[cell_line_name]['FSC'] - 1
            fsc_voltage_high = VOLTAGE_RANGES[cell_line_name]['FSC']
            ssc_voltage_low = VOLTAGE_RANGES[cell_line_name]['SSC'] - 1
            ssc_voltage_high = VOLTAGE_RANGES[cell_line_name]['SSC']            
        
        #@TODO: adjust these to use less volume once we know our voltage ranges
        p.flow_analyze("%s_cell_flow_data"%cell_line_name, 
                       FSC={
                           "voltage_range": {
                               "low": "%s:volt"%fsc_voltage_low,
                               "high": "%s:volt"%fsc_voltage_high
                               },
                           "area": True,             
                           "height": True,           
                           "weight": False           
                           }, 
                       SSC={
                           "voltage_range": {
                               "low": "%s:volt"%ssc_voltage_low,
                               "high": "%s:volt"%ssc_voltage_high
                               },
                           "area": True,             
                           "height": True,           
                           "weight": False           
                        }, 
                       neg_controls=[{
                           "well": flow_well,
                           "volume": flow_neg_control_volume,
                           "channel": ['FSC','SSC']
                        }], 
                       samples=[{
                           "well": flow_well,
                           "volume": FLOW_TEST_SAMPLE_VOLUME,
                       }])   
        
        return aggregate_cells_well

    
if __name__ == '__main__':
    raise Exception('cell maintenance is meant to be appended to another protocol, not called on its own')
