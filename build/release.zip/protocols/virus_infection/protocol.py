from __future__ import print_function
import math
from transcriptic_tools.utils import (ul, ml, ug, ng, init_inventory_well, 
                                      get_well_dead_volume, get_volume, floor_volume,
                                      uniquify)
from transcriptic_tools.harness import run
from autoprotocol import Unit
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container

from protocols.cell_maintenance_part2.protocol import split_cells

from protocols.cell_maintenance_part1.protocol import cell_maintenance, trypsonize_plate

from protocols.hsv1_transfection.protocol import freeze_virus_plate
from protocols.virus_titration.protocol import perform_plaque_staining

PLATE_REQS = {
    'count':1,
    'type':'vero',
    'confluency_percent': 60
}


def main(p, params):    
    """This is the base protocol that we will send cell plates to that are left over from other experiments
    """    
    
    assert(isinstance(p,Protocol))
    
    p.mammalian_cell_mode = False
    
    plate_reqs = PLATE_REQS.copy()
    
    
    well_count = params.get('well_count',6)
    flash_freeze = params.get('flash_freeze',True)
    plaque_stain = params.get('plaque_stain',False)
    
    if flash_freeze and plaque_stain:
        raise Exception('We can\'t flash freeze while also plaque staining. Flash freezing detaches cells')    
    
    negative_control = False
    if params.get('negative_control',False):
        if well_count<6:
            well_count+=1
        negative_control=True
    
    well_indexes = ['A1','A2','A3','B1','B2','B3'][:well_count]
    plate_reqs['well_indexes'] = well_indexes
    
    
    #setup
    
    starter_cell_plate = None
    if not params.get('skip_splitting',False):
        
        #which plate to use take cells from
        starter_cell_plate = params['cell_plate']        
        
        #cell to hold trypsonized cells
        aggregate_cells_well = p.get_10ml_well('trypsonized_cells',
                                               discard=True)
    
        trypsonize_plate(p, starter_cell_plate, aggregate_cells_well)    
    
        cell_plate = split_cells(p, aggregate_cells_well, params['cells_per_ul'],
                                 plate_reqs, flow_analyze=False, 
                                 #chosen to only need 24 hours of incubation
                                 desired_replate_cells_per_well = 360*1000)[0]
    else:
        cell_plate = params['cell_plate']
    
    cell_wells = cell_plate.wells(well_indexes)
    
    experiment_cell_wells = cell_wells
    negative_control_cell_wells = []
    
    if negative_control:
        experiment_cell_wells = cell_wells[:-1]
        negative_control_cell_well = cell_wells[-1]
        negative_control_cell_well.name = 'negative_control_well'

    p.trash_max_volume(cell_wells)    

    virus_well = params["virus_wells"][0]

    #infection procedure starts here (although its using an existing plate)
    
    distribute_volume = floor_volume(get_volume(virus_well, aspiratable=True) / len(experiment_cell_wells))
    dispense_speed = '%s:microliter/second'%min(distribute_volume / 3, ul(900)).to('microliter').magnitude
    
    #bring the wells back up to 3ml

    p.provision_by_name('culture_medium', cell_wells, ml(3) - get_volume(cell_wells[0],
                                                                         aspiratable=True) - distribute_volume)
    
    p.distribute(virus_well, experiment_cell_wells, distribute_volume,
                 #gently to prevent merging liposomes (15 seconds)
                 mix_before=True, repetitions=2,mix_vol=ul(900),flowrate='120:microliter/second',
                 aspirate_speed='120:microliter/second',
                 distribute_target={'dispense_speed':dispense_speed},
                 allow_carryover=True,
                 )
    
    p.mix(experiment_cell_wells)    
    
    p.incubate(cell_plate, 'warm_37', '72:hour')
    
    freeze_virus_plate(p, cell_plate, experiment_cell_wells, flash_freeze=flash_freeze)
    
    if plaque_stain:
        perform_plaque_staining(p, cell_plate, cell_wells)
        
    else:
        #we may be able to eventually always discard but right now we may need to re-stain
        cell_plate.discard()
            
    # --- cleanup ----
    #discard the used cell plates
    if starter_cell_plate:
        starter_cell_plate.discard()
        
    
if __name__ == '__main__':
    run(main, "VirusInfection")
