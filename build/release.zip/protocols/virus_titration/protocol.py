from __future__ import print_function
import math
from transcriptic_tools.utils import (ul, ml, ug, init_inventory_well, 
                                      get_well_dead_volume, get_column_wells)
from transcriptic_tools.harness import run
from autoprotocol import Unit
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container

from protocols.cell_maintenance_part2.protocol import split_cells

from protocols.cell_maintenance_part1.protocol import cell_maintenance, trypsonize_plate

from transcriptic_tools.enums import Reagent

PLATE_REQS = {
    'count':4,
    'container_type': '6-flat-tc',
    'cell_type':'vero',
    'confluency_percent': 100
}

def main(p, params):    
    """This is the base protocol that we will send cell plates to that are left over from other experiments
    """

    assert(isinstance(p,Protocol))

    #which plate to use take cells from
    starter_cell_plate = params['cell_plate']

    #cell to hold trypsonized cells
    aggregate_cells_well = p.get_10ml_well('trypsonized_cells',
                                           discard=True)

    trypsonize_plate(p, starter_cell_plate, aggregate_cells_well)

    #setup
    cell_plates = split_cells(p, aggregate_cells_well, params['cells_per_ul'],
                             PLATE_REQS, flow_analyze=False)
    
    virus_well = params['virus_well']
    
    init_inventory_well(virus_well)
    
    dilution_plate = p.ref("virus_dilution_plate", cont_type="24-deep", 
                           storage="ambient",
                           #TBD
                           discard=True)    
    
    dilution_wells = []
    for i in range(0,5):
        dilution_str = "1E%s"%(-2-i)
        dilution_well = dilution_plate.well(i)
        dilution_well.name = 'diluted_virus_%s'%dilution_str
        dilution_wells.append(dilution_well)
        
    p.provision_by_name(Reagent.dmem_fbs_ps, dilution_wells, ml(9))
    
    #create dilution 1E-2
    p.transfer(virus_well, dilution_wells[0], ml(1),
               mix_after=True, repetitions_a=10,
               mix_before=True,repetitions_b=3,mix_percent_b=50,mix_seconds_b=3)
    
    
    #create dilutions 1E-3-->1E-6    
    for i in range(1,5):
        p.transfer(dilution_wells[i-1], dilution_wells[i], ml(1),
                   mix_after=True,repetitions=10 )     

    p.trash_max_volume(cell_plates)
    
    cell_plate_well_index = 0
    #Transfer 2ml of each virus dilution into 2 wells of each plate 
    #(label the wells with the corresponding dilution). 
    #Mix each tube before transferring from it.
    
    
    #group wells together that will have the same dilution
    titration_well_sets = [
        #plate1 + plate3, col1 (1E-2)
        get_column_wells(cell_plates[0],0)+get_column_wells(cell_plates[2],0),
        #...col2 (1E-3)
        get_column_wells(cell_plates[0],1)+get_column_wells(cell_plates[2],1),
        #...col3 (1E-4)
        get_column_wells(cell_plates[0],2)+get_column_wells(cell_plates[2],2),
        #plate2 + plate4, col1 (1E-5)
        get_column_wells(cell_plates[1],0)+get_column_wells(cell_plates[3],0),
        #...col2 (1E-6)
        get_column_wells(cell_plates[1],1)+get_column_wells(cell_plates[3],1),
        #...col3 (no virus)
        get_column_wells(cell_plates[1],2)+get_column_wells(cell_plates[3],2),
    ]
    
    for dilution_index in range(0,5):
        dilution_tube = dilution_wells[dilution_index]
        dest_wells = titration_well_sets[dilution_index]
        
        for dest_well in dest_wells:
            dest_well.name = dilution_tube.name    
            
        p.distribute(dilution_tube, 
                     dest_wells, ml(2),
                     mix_before=True,
                     allow_carryover=True
                     )        
            
        #we can use the same mixing tip because the source is all the same
        p.mix(dest_wells,
              mix_seconds=3.5,
              mix_percent=50,
              repetitions=2,
              one_tip=True)
        

    p.dispense_by_name(Reagent.dmem_fbs_ps, [cell_plates[1],
                                             cell_plates[3]],[{'column': 2, 'volume':ml(2)}])
    
    for dest_well in titration_well_sets[5]:
        dest_well.name = 'no virus'

    p.incubate(cell_plates, 'warm_37', '2:hour', shaking=True)
    
    #trash in sets of clones so that we can use a single tip for each set
    for wells in titration_well_sets:
        p.trash_max_volume(wells)
    
    p.dispense_by_name(Reagent.dmem_fbs_ps, cell_plates, ml(2))
    
    incubate_hour_plate_sets = [
        [3*24,cell_plates[0:2]],
        [6*24,cell_plates[2:4]]
        ]
    
    for incubate_hours, plates_to_incubate in incubate_hour_plate_sets:
        for cell_plate in plates_to_incubate:
            p.incubate(cell_plate, 'warm_37', '%s:hour'%incubate_hours)
            p.set_container_name(cell_plate,'%s_hour_incubate_%s'%(incubate_hours, cell_plate.name))
            perform_plaque_staining(p, cell_plate)
    
    # ----- cleanup ------
    
    #we are not discarding in-case we want to re-image
    for cell_plate in cell_plates:
        cell_plate.set_storage('ambient')    
        p.set_container_name(cell_plate,'stained_dried_%s'%cell_plate.name)
        #cell_plate.discard()   
    
    starter_cell_plate.discard()
    
    
def perform_plaque_staining(p, cell_plate, stain_wells=None):
    """

    Use stain_wells if you only want to stain a subset of wells
    
    """
    p.mammalian_cell_mode = False
    
    if not stain_wells:
        stain_wells = cell_plate.all_wells()
    
    assert isinstance(cell_plate, Container)
    
    if cell_plate.container_type.shortname.startswith('96-flat'):
        raise Exception('This method is not for 96-well plates anymore')
    
    assert(isinstance(p,Protocol))
    
    
    p.trash_max_volume(stain_wells)
    
    
    for i in range(0,4):
        p.provision_by_name(Reagent.pbs, stain_wells, ml(3))
        p.trash_max_volume(stain_wells)
        
    p.provision_by_name('Methanol', stain_wells, ml(3))
    
    p.incubate(cell_plate, 'ambient', '10:minute', co2=0)
    
    p.trash_max_volume(stain_wells)
    
    p.provision_by_name('Crystal_Violet', stain_wells, ml(3))
        
    p.incubate(cell_plate, 'ambient', '10:minute', co2=0)    
    
    p.trash_max_volume(stain_wells)

    for i in range(0,3):
        p.provision_by_name('water', stain_wells, ml(3))
        p.trash_max_volume(stain_wells)

    p.incubate(cell_plate,'warm_37','12:hour',co2=0) 
    p.uncover(cell_plate)
    p.image_plate(cell_plate, 'top', 'stained_plate_%s'%cell_plate.name)
    
    
if __name__ == '__main__':
    run(main, "VirusTitration")
