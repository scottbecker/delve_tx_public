from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_well_max_volume,
                                      get_column_wells,
                                      copy_cell_line_name, set_property, get_volume)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

def bacteria_counting(p, source_bacteria_well,
                                antibiotic=None,
                                second_antibiotic=None):
    
    cell_line_name = get_cell_line_name(source_bacteria_well)
    
    assert isinstance(p,Protocol)
    
    if not antibiotic:
        #get the antibiotic from the source well
        well_antibiotic_str = source_bacteria_well.properties.get('antibiotic')
        if well_antibiotic_str:
            antibiotic = Antibiotic.from_string(well_antibiotic_str)
        else:
            raise Exception('Source Well must have property \'antibiotic\' set if antibiotic not specified')
    
    assert isinstance(antibiotic,Antibiotic)    
    
    
    dilution_plate = p.ref("dilution_plate", cont_type="96-pcr",
                           discard=True)    
    
    dilution_wells = []
    for i in range(0,10):
        dilution_str = "1E%s"%(-1-i)
        dilution_well = dilution_plate.wells_from(0 if not i else dilution_wells[-1].index,2,columnwise=True)[1]
        dilution_well.name = 'diluted_%s'%dilution_str
        dilution_wells.append(dilution_well)

    p.provision_by_name(Reagent.m9_minimal_media, get_column_wells(dilution_plate, 
                                                                   [0,1]), ul(130))
    
    #create dilution 1E-1
    p.transfer(source_bacteria_well, dilution_wells[0], ul(15),
               mix_after=True,repetitions_a=10,
               mix_before=True)

    #create dilutions 1E-2-->1E-10   
    for i in range(1,10):
        p.transfer(dilution_wells[i-1], dilution_wells[i], ul(15),
                   mix_after=True)       
        
    
    if second_antibiotic:
        p.add_antibiotic(dilution_wells, second_antibiotic)        

    #spread onto a 6 well agar plate
    
    agar_pick_plate = p.create_agar_plate('pick_plate', '6-flat', antibiotic=antibiotic,
                                          storage=Temperature.cold_4)
    
    
    for i in range(0,6):
        p.spread(dilution_wells[9-i], agar_pick_plate.well(i), ul(100))
        agar_pick_plate.well(i).name = dilution_wells[9-i].name
    
    p.incubate(agar_pick_plate, Temperature.warm_37, '15:hour')
    
    p.image_plate(agar_pick_plate, mode="top", dataref='agar_plate_post_incubate')
        
    
def main(p, params):    
    """Run a serial dilution up to 10^-10 and then plate the lowest 6 concentrations on a 6 well agar plate
    """
    #bacterial protocol
    p.mammalian_cell_mode = False
    
    bacteria_counting(p, params['bacteria_well'],
                      Antibiotic.from_string(params['antibiotic']) if params['antibiotic'] != 'cell_line' else None,
                      Antibiotic.from_string(params['second_antibiotic']) if params['second_antibiotic'] != 'cell_line' else None
                    )
    
if __name__ == '__main__':
    run(main, "BacteriaCounting")
