from __future__ import print_function
import math
from transcriptic_tools.utils import (ul, ml, ug, ng, init_inventory_well, 
                                      get_well_dead_volume, get_volume, floor_volume,
                                      uniquify)
from transcriptic_tools.harness import run
from autoprotocol import Unit
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container

from protocols.cell_maintenance_part2.protocol import split_cells

from protocols.cell_maintenance_part1.protocol import cell_maintenance, trypsonize_plate

PLATE_REQS = {
    'count':1,
    'type':'vero',
    'confluency_percent': 60
}


def freeze_virus_plate(p, cell_plate, cell_wells, flash_freeze=True):

    cryo_tubes = []
    well_count = len(cell_wells)
    for i in range(0,well_count):
        cryo_tubes.append(p.ref(uniquify('cryo_wt_hsv1_virus_%s'%i), cont_type='screw-cap-1.8', 
                                storage='cold_80'))    
    
    if not flash_freeze:
        p.transfer(cell_wells,cryo_tubes,ml(1.7),
                   mix_before=True)
    else:    
        for i in range(0,2):
            p.incubate(cell_plate, 'cold_20', '40:minute', co2=0)
            p.incubate(cell_plate, 'ambient', '3:minute', co2=0)
            
        freeze_tubes = []
        for i in range(0,well_count):
            freeze_tubes.append(p.ref('freeze_tube_%s'%i, cont_type='micro-2.0', 
                                     discard=True))
            
        p.transfer(cell_wells,freeze_tubes,ml(2),
                   mix_before=True)
  
        cryo_tube_index = 0
        for freeze_tube in freeze_tubes:
            for i in range(0,3):
                p.flash_freeze(freeze_tube, '10:second')
                p.incubate(freeze_tube, 'ambient', '3:minute', co2=0)
            p.spin(freeze_tube, '4000:g', '3:minute')
            p.transfer(freeze_tube, cryo_tubes[cryo_tube_index], ul(1700))
            
            cryo_tube_index+=1
            
    return cryo_tubes
    


def main(p, params):    
    """This is the base protocol that we will send cell plates to that are left over from other experiments
    """
    
    assert(isinstance(p,Protocol))
    
    #which plate to use take cells from
    starter_cell_plate = params['cell_plate']

    #cell to hold trypsonized cells
    aggregate_cells_well = p.get_10ml_well('trypsonized_cells',
                                           discard=True)

    trypsonize_plate(p, starter_cell_plate, aggregate_cells_well)


    plate_reqs = PLATE_REQS.copy()
    
    well_count = params.get('well_count',6)
    well_indexes = ['A1','A2','A3','B1','B2','B3'][:well_count]
    plate_reqs['well_indexes'] = well_indexes
    
    #setup
    cell_plate = split_cells(p, aggregate_cells_well, params['cells_per_ul'],
                             plate_reqs, flow_analyze=False, 
                             #chosen to only need 24 hours of incubation
                             desired_replate_cells_per_well = 360*1000)[0]
    
    cell_wells = cell_plate.wells(well_indexes)
    
    tube_a = p.ref('tube a', cont_type='micro-2.0', discard=True)
    tube_b = p.ref('tube b', cont_type='micro-2.0', discard=True)
    
    p.provision_by_name('OptiMem', [tube_a.well(0),
                                    tube_b.well(0)], ul(100))
    
        
    dna_well = params['hsv1_dna_well']
    
    init_inventory_well(dna_well)
    
    dna_concentration_ng_per_ul = Unit(dna_well.properties['mass_conc_ng_per_ul'],'nanogram/microliter')
    dna_concentration_ul_per_ng = (1/dna_concentration_ng_per_ul).to('microliter/nanogram')
    dna_volume_to_take = ul(math.ceil((ng(150) * dna_concentration_ul_per_ng).magnitude))
    
    p.transfer(dna_well, tube_a, dna_volume_to_take, mix_before=True,
               one_tip=False, mix_after=True)
    
    p.provision_by_name('Lipofectamine', tube_b, ul(2), mix_after=True,
                        #gently to prevent merging liposomes [5 seconds per mix]
                        repetitions=2,mix_vol=ul(70),flowrate='28:microliter/second'
                        )
    
    #atmospheric co2
    p.incubate(tube_b, 'ambient', '5:minute', co2=0)
    
    p.transfer(tube_a, tube_b,
               tube_a.well(0).volume - get_well_dead_volume(tube_a),
               mix_before=True,
               mix_after=True,
               #gently to prevent merging liposomes
               repetitions_a=2,mix_vol_a=ul(150),flowrate_a='28:microliter/second'               
               )
    
    #atmospheric co2
    p.incubate(tube_b, 'ambient', '20:minute', co2=0)    
    
    additional_volume_to_reach_2ml = ml(2) - tube_b.well(0).volume

    
    
    if additional_volume_to_reach_2ml>ul(0):
        
        #we provision into another tube so we can control the speed of dispensing
        temp_optimem_well = p.ref('temp_optimem_tube', cont_type='micro-2.0', 
                                  discard=True).well(0)
        
        p.provision_by_name('OptiMem', temp_optimem_well, additional_volume_to_reach_2ml+\
                            get_well_dead_volume(temp_optimem_well))
        
        p.transfer(temp_optimem_well, tube_b, additional_volume_to_reach_2ml, 
                   one_tip=True, 
                   #total dispense time is 13 seconds
                   dispense_speed='130:microliter/second',
                   aspirate_speed='1000:microliter/second')
    
    p.trash_max_volume(cell_wells)
    
    p.provision_by_name('PBS', cell_wells, ml(3))
    
    p.trash_max_volume(cell_wells)
    
    p.provision_by_name('OptiMem',cell_wells,ml(3))
    
    p.trash_max_volume(cell_wells)
    
    #p.provision_by_name('OptiMem', cell_wells, ul(500))
    
    #infection procedure starts here (although its using an existing plate)
    
    distribute_volume = floor_volume(get_volume(tube_b,aspiratable=True) / well_count)
    dispense_speed = '%s:microliter/second'%min(distribute_volume / 3, ul(900)).to('microliter').magnitude
    
    p.distribute(tube_b, cell_wells, distribute_volume,
                 #gently to prevent merging liposomes (15 seconds)
                 mix_before=True, repetitions=2,mix_vol=ul(900),flowrate='120:microliter/second',
                 aspirate_speed='120:microliter/second',
                 dispense_speed=dispense_speed,
                 allow_carryover=True
                 )
    
    p.incubate(cell_plate, 'warm_37', '5:hour')
    
    p.trash_max_volume(cell_wells)
    
    p.provision_by_name('culture_medium', cell_wells, ml(2.5))
    
    p.incubate(cell_plate, 'warm_37', '24:hour')
    
    p.trash_max_volume(cell_plate)
        
    p.provision_by_name('culture_medium', cell_wells, ml(3))    
    
    p.incubate(cell_plate, 'warm_37', '72:hour')
    
    
    cryo_tubes = freeze_virus_plate(p, cell_plate,cell_wells,flash_freeze=params.get('flash_freeze',False))
    
    # ---- This section is temporary and only used for measuring evaporation
    extra_solution_tube =  p.ref('extra_solution_tube', cont_type='micro-1.5', 
                            discard=True)    
    
    p.transfer(cell_wells[0],extra_solution_tube,ml(1))
    
    #used to measure how much volume we had remaining
    p.measure_volume(extra_solution_tube.well(0), "extra_solution_tube_volume")
    p.measure_volume(cryo_tubes[0].well(0), "cryo_tube_0_volume")
    
    # --- cleanup ----
    #discard the used cell plates
    
    cell_plate.discard()
    
    starter_cell_plate.discard()
    
    
    
if __name__ == '__main__':
    run(main, "HSV1Transfection")
