from __future__ import print_function
from transcriptic_tools.utils import ml, ul
from transcriptic_tools.harness import run
from transcriptic_tools.custom_protocol import CustomProtocol as Protocol
from autoprotocol.protocol import Container

def main(p, params):    
    assert isinstance(p, Protocol)
    inv = {
        'water':'rs17gmh5wafm5p'    #catalog: te
    }
    
    #create a container 
    
    well = p.ref("cells", cont_type="micro-2.0", storage="cold_80", discard=False).well(0)
    
    p.provision(inv["water"], well, ul(1000))
    
if __name__ == '__main__':
    run(main, "CreateFakeCells")
