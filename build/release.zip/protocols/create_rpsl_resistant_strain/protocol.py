from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_column_wells,
                                      copy_cell_line_name, set_property, set_well_name,
                                      get_volume)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

def create_rpsl_resistant_strain(p, source_bacteria_well,
                                 antibiotic=None,
                                 destroy_source_tube=False):

    cell_line_name = get_cell_line_name(source_bacteria_well)

    assert isinstance(p,Protocol)

    if not antibiotic:
        #get the antibiotic from the source well
        well_antibiotic_str = source_bacteria_well.properties.get('antibiotic')
        if well_antibiotic_str:
            antibiotic = Antibiotic.from_string(well_antibiotic_str)
        else:
            raise Exception('Source Well must have property \'antibiotic\' set if antibiotic not specified')
    
        assert isinstance(antibiotic,Antibiotic)    

    growth_plate = p.ref('growth_plate', cont_type="96-deep", storage=Temperature.cold_4)
    
    growth_wells = get_column_wells(growth_plate, 0)  
    
    set_well_name(growth_wells, 'amplify_hm63_well')
    
    p.add_antibiotic(growth_wells, antibiotic, broth_volume=ul(1900))
    
    p.distribute(source_bacteria_well,growth_wells,ul(8),allow_carryover=True,
                 mix_after=True,
                 mix_vol = ul(8),
                 mix_before=True)    
    
    p.incubate(growth_plate, Temperature.warm_37, '15:hour')
    
    p.measure_bacterial_density(growth_wells)
    
    p.add_antibiotic(growth_wells, Antibiotic.strep)
    
    p.incubate(growth_plate, Temperature.warm_37, '15:hour')
    
    p.measure_bacterial_density(growth_wells)
    
    mix_well =  p.ref('temp_mix_tube', cont_type='micro-2.0',
                      discard=True).well(0)    
    
    p.consolidate(growth_wells, mix_well, ul(250),mix_after=True,allow_carryover=True)
    
    agar_pick_plate = p.create_agar_plate('pick_plate', '1-flat', antibiotic=antibiotic)
    
    p.spread(mix_well, agar_pick_plate.well(0), ul(300))
    
    p.incubate(agar_pick_plate, Temperature.warm_37, '15:hour')
    
    p.image_plate(agar_pick_plate, mode="top", dataref='agar_plate_post_incubate')

    autopick_column_index = 11
    autopick_destination_wells = get_column_wells(growth_plate,autopick_column_index)
    
    p.add_antibiotic(autopick_destination_wells, antibiotic, broth_volume=ul(1800),
                     mix_after=False)
    p.add_antibiotic(autopick_destination_wells, Antibiotic.strep)
    
    p.autopick(agar_pick_plate.well(0), autopick_destination_wells, dataref='autopick')  
    
    for i in range(0,len(autopick_destination_wells)):
        well = autopick_destination_wells[i] 
        well.name = 'autopick_hme63_rpsl_%s'%i
    
    p.incubate(growth_plate, Temperature.warm_37, '15:hour')
    
    p.measure_bacterial_density(autopick_destination_wells)    
    
    
    #miniprep_dest_plate = p.ref('seq_plate', cont_type="96-pcr", storage=Temperature.cold_4) 
    #miniprep_dest_wells = get_column_wells(miniprep_dest_plate, 0)
    
    
    copy_cell_line_name(source_bacteria_well, growth_plate)
    set_property(growth_plate,'antibiotic',antibiotic.name)        

    #commenting out the miniprep section since its so expensive (we only want to do it if we know we definitely have bacteria to miniprep)
    ##p.miniprep(autopick_destination_wells, miniprep_dest_wells)
    ###measure the concentration of each well
    ##p.measure_concentration(miniprep_dest_wells, 'rpsl_hme63_dna_conc','DNA')
    
    if destroy_source_tube:
        source_bacteria_well.container.discard()    


def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False

    create_rpsl_resistant_strain(p, params['bacteria_tube'].well(0),
                                 Antibiotic.from_string(params['antibiotic']) if params['antibiotic'] != 'cell_line' else None,
                                 params['destroy_source_tube']
                                )

if __name__ == '__main__':
    run(main, "CreateRpsLResistantStrain")
