from __future__ import print_function
import datetime
from decimal import Decimal
import math
from transcriptic_tools.utils import (ul, ml, get_well_max_volume, uniquify, get_well_dead_volume,
                                      copy_cell_line_name,get_cell_line_name, get_volume,
                                      floor_volume)
from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container

from protocols.cell_maintenance_part1.protocol import cell_maintenance, trypsonize_plate

PLATE_REQS = {
    'count': 3,
    'confluency_percent': 100
}

def ceil_to_half_integer(number):
    """Round a number to the closest half integer.
    >>> round_of_rating(1.3)
    1.5
    >>> round_of_rating(2.6)
    2.5
    >>> round_of_rating(3.0)
    3.0
    >>> round_of_rating(4.1)
    4.0"""

    return math.ceil(number * 2) / 2

def calculate_cell_culture_volume_needed(total_cells_desired,cells_per_ul,volume_of_test_sample):
    
    volume_needed = ul(round(total_cells_desired * (1.0 / cells_per_ul)))
    
    return volume_needed

def get_total_cell_capacity(plate_type):
    if plate_type == '6-flat-tc':
        #940.3 mm^2 growth area
        #http://bit.ly/2ao3I2H
        total_cell_capacity = 1.2*1000*1000
    elif plate_type == '96-flat-tc':
        #37.0 mm^2 growth area
        total_cell_capacity = 47*1000
    else:
        raise Exception('unknown plate type for culturing cells') 
    
    return total_cell_capacity

def hours_needed_to_reach_confluency(starting_cell_count, plate_type, confluency_percent):
    

    total_cell_capacity = get_total_cell_capacity(plate_type)
    #doubling rate of cells
    #calculated using http://www.miniwebtool.com/exponential-growth-calculator
    r = 0.02888113
    
    confluency = confluency_percent / 100.0
    
    #based on P(t) = P0e^(r*t)
    hours = math.log(total_cell_capacity * confluency / starting_cell_count * 1.0, math.e) / r
    
    #return nearest half hour
    return ceil_to_half_integer(round(hours,4))


def starting_cell_count_needed_to_reach_confluency(incubate_hours, plate_type,
                                                   confluency_percent):
    
    total_cell_capacity = get_total_cell_capacity(plate_type)   

    #doubling rate of cells
    #calculated using http://www.miniwebtool.com/exponential-growth-calculator
    r = 0.02888113
    
    confluency = confluency_percent / 100.0
    
    final_cell_count = total_cell_capacity * confluency
    
    #based on P(t) = P0e^(r*t)
    #P(t) / e^(r*t) = P0
    
    starting_cell_count = final_cell_count / math.pow(math.e, r*incubate_hours)
    
    return round(starting_cell_count,0)    
    

def split_cells(p, trypsonized_cell_well, cells_per_ul, plate_requirements, flow_analyze=True,
                desired_replate_cells_per_well=150*1000,
                incubate_hours=None,
                confluency_percent=None,
                end_incubation_early=False,
                re_trypsonize=False
                ):    
    """This is the base protocol that we will send cell plates to that are left over from other experiments
    
    Returns a reference to a list of plates with a single well that contains all of the cells 
    
    """
    assert isinstance(p, Protocol)
    
    if not plate_requirements:
        plate_requirements = PLATE_REQS


    if re_trypsonize:
        p.trash_volume(trypsonized_cell_well, trypsonized_cell_well.volume - ul(1030))
        p.transfer(trypsonized_cell_well, trypsonized_cell_well.container.well(1), ml(1)+ul(15))
        trypsonize_plate(p,trypsonized_cell_well.container,wells = [trypsonized_cell_well])
        p.transfer(trypsonized_cell_well.container.well(1), trypsonized_cell_well, ml(1))

    #create new plates
    cell_plates = []
    all_replate_wells = []
    cell_line_name = get_cell_line_name(trypsonized_cell_well)
    container_type = plate_requirements['container_type'] if 'container_type' in plate_requirements else '6-flat-tc'
    for x in range(0,plate_requirements['count']):
        cell_plate = p.ref(uniquify("replated_%s_cells_%s"%(cell_line_name,x)),
                           cont_type=container_type, storage="warm_37",
                           cell_line_name=cell_line_name)

        if 'well_indexes' in plate_requirements:
            all_replate_wells+=cell_plate.wells(plate_requirements['well_indexes'])
        else:
            all_replate_wells+=cell_plate.all_wells()
        cell_plates.append(cell_plate)

    if 'use_all_volume' in plate_requirements and 'incubate_hours' in plate_requirements:
        
        incubate_hours = plate_requirements['incubate_hours']
        replate_volume_needed = floor_volume(get_volume(trypsonized_cell_well, aspiratable=True) / len(all_replate_wells) * 1.0)
        
    elif incubate_hours:
        desired_replate_cells_per_well = starting_cell_count_needed_to_reach_confluency(incubate_hours, 
                                                      '6-flat-tc', 
                                                      confluency_percent if confluency_percent else plate_requirements['confluency_percent'])
        
        
        replate_volume_needed = calculate_cell_culture_volume_needed(desired_replate_cells_per_well, 
                                                                     cells_per_ul, 
                                                                     ml(0.5))        
        
        
    else:
        replate_volume_needed = calculate_cell_culture_volume_needed(desired_replate_cells_per_well, 
                                                                     cells_per_ul, 
                                                                     ml(0.5))
        
    
        
        incubate_hours = hours_needed_to_reach_confluency(desired_replate_cells_per_well, container_type, 
                                                          plate_requirements['confluency_percent'])
        
        if trypsonized_cell_well.volume < ul(60):
            raise ValueError('not enough volume of trypsonized cells. We have %s'%trypsonized_cell_well.volume)
        

        #not enough volume of trypsonized cells. Cell concentration too low
        if trypsonized_cell_well.volume <= replate_volume_needed*len(all_replate_wells):
            #we are going to adjust the volume we take to the max we can take and adjust the hours we run incubate for
            
            #get the max volume we have available
            capturable_volume = trypsonized_cell_well.volume - get_well_dead_volume(trypsonized_cell_well)
            capturable_volume = capturable_volume.to('microliter')
            new_cell_volume_per_replate_well = ul(math.floor(1.0 * capturable_volume.magnitude / len(all_replate_wells)))
            
            #figure out how many cells are in that volume
            starting_cell_count = math.floor(new_cell_volume_per_replate_well / replate_volume_needed * desired_replate_cells_per_well)
            incubate_hours = hours_needed_to_reach_confluency(starting_cell_count, container_type, 
                                                              plate_requirements['confluency_percent'])
            
            replate_volume_needed = new_cell_volume_per_replate_well
            
        
     #throw an exception if we don't have a high enough concentration 
     #(might be able to include this with the below readjustment)
 

    if replate_volume_needed > get_well_max_volume(all_replate_wells[0]):
        raise ValueError('desired start cell count is too high for '+\
                        'given concentration. We don\'t have %s of volume'%replate_volume_needed)
    
    
    p.distribute(trypsonized_cell_well, all_replate_wells, replate_volume_needed,
                 allow_carryover=True,
                 mix_before=True)
    
    copy_cell_line_name(trypsonized_cell_well, all_replate_wells)
    
    culture_medium_ml = min(ml(3),get_well_max_volume(cell_plates[0])) - replate_volume_needed
    
    if culture_medium_ml>ul(0):
        #add culture medium to bring each well up to 3ml
        p.provision_by_name('culture_medium', all_replate_wells, culture_medium_ml)
        
    p.mix(all_replate_wells)
    
    
    #discard the container holding the trypsonized cells if we have used all of its volume
    if all([well.volume <= get_well_dead_volume(well) * 2 \
            for well in trypsonized_cell_well.container.all_wells()]):
        trypsonized_cell_well.container.discard()
    
    
    #send plates back to maintenance to continue growing
    return cell_maintenance(p, cell_plates,
                            flow_analyze=flow_analyze,
                            incubate_hours=incubate_hours if not end_incubation_early else 0.02)
    
    
def get_splitting_plate_requirements(cells_per_ul,
                                     tryponized_cells_well,
                                     max_plate_count=3):
    """
    Intelligently determine the number of plates we can make with the given concentraiton of cells
    """
    
    #convert desired incubate hours into cell count
    min_starting_cell_count = starting_cell_count_needed_to_reach_confluency(5*24, 
                                                                             '6-flat-tc', 
                                                                             100)
    
    available_volume = get_volume(tryponized_cells_well,aspiratable=True).to('microliter').magnitude
    
    wells_we_can_replate = int(math.floor(available_volume*cells_per_ul / min_starting_cell_count))
    

    #@TODO: add intelligence to drop to fewer plates if we are going to end on a weekend
    
    #temp work around to deal with weekend issue
    
    if wells_we_can_replate >= max_plate_count*6:
        #default
        return {
            'count': max_plate_count,
            'container_type': '6-flat-tc',
            'confluency_percent': 100
        }
    
    if wells_we_can_replate >= 12:
        #default
        return {
            'count': 2,
            'container_type': '6-flat-tc',
            'confluency_percent': 100
        }    
    
    if wells_we_can_replate==0:
        return {
            'count': 1,
            'container_type': '6-flat-tc',
            'use_all_volume': True,
            'well_indexes': ['A1','A2'],
            'incubate_hours': 3*24,
            'confluency_percent': 100
        }         
    

    #function will figure out the optimal volume and incubate hours
    return {
        'count': 1,
        'container_type': '6-flat-tc',
        #'use_all_volume': True,
        'well_indexes': ['A1','A2','A3','B1','B2','B3'][:wells_we_can_replate],
        #'incubate_hours': 3*24,
        'confluency_percent': 100
    }       
    
def main(p,params):
    
    tryponized_cells_well = params["trypsonized_cell_wells"][0]
    
    if params.get('custom_trypsonized_cell_well_volume',None):
        tryponized_cells_well.volume = ul(params['custom_trypsonized_cell_well_volume'])
    
    
    plate_requirements = None
    
    if params.get('use_all_volume',False) and params.get('incubate_hours',None):
        plate_requirements = {
            'count': params.get('max_plate_count',3),
            'container_type': '6-flat-tc',
            'use_all_volume': True,
            'well_indexes': ['A1','A2','A3','B1','B2','B3'],
            'incubate_hours': params['incubate_hours'],
            'confluency_percent': params.get('confluency_percent',100)
        }     
    else:
        plate_requirements = get_splitting_plate_requirements(params['cells_per_ul'],
                                         tryponized_cells_well,
                                         max_plate_count=params.get('max_plate_count',3),
        
                                         )        
    
    split_cells(p, tryponized_cells_well , params['cells_per_ul'],
                plate_requirements=plate_requirements,
                incubate_hours=params.get('incubate_hours',None),
                confluency_percent=params.get('confluency_percent',None),
                flow_analyze=params.get('flow_analyze',True),
                end_incubation_early=params.get('end_incubation_early',False),
                re_trypsonize=params.get('re_trypsonize',False))
    
    
if __name__ == '__main__':
    run(main, "CellSplitting")
