from __future__ import print_function
import math
from transcriptic_tools.utils import (ml, ul, space_available,get_well_dead_volume,
                                      floor_volume,
                                      get_column_wells, total_plate_available_volume)
from transcriptic_tools.harness import run
from transcriptic_tools.custom_protocol import CustomProtocol as Protocol
from autoprotocol.protocol import Container
from transcriptic_tools.enums import Reagent
from lib import round_up



def refill_culture_medium(p, culture_medium_plate,volume=None):    
    assert isinstance(p, Protocol)
    assert isinstance(culture_medium_plate,Container)
    
    max_volume = total_plate_available_volume(culture_medium_plate) - \
        24*get_well_dead_volume(culture_medium_plate.well(0))    
    if not volume:
        volume = max_volume
    
    if volume > max_volume:
        raise Exception('Can\'t put more than 240ml in the culture medium plate')

    
    dead_volume = get_well_dead_volume(culture_medium_plate).magnitude

    wells_to_fill = []
    volumes = [] 

    ul_remaining_to_fill = volume.to('microliter').magnitude
    
    col_count = culture_medium_plate.container_type.col_count
    
    
    #operate on a column of wells at the same time to save $ with dispense
    column_volumes = []
    for column_index in range(0,col_count):
        if ul_remaining_to_fill<ml(4).magnitude:
            break
        
        col_wells = get_column_wells(culture_medium_plate, column_index)
                
        #only do this if every well has the same volume (simplifies the problem)
        if not all([well.volume == col_wells[0].volume for well in col_wells]):
            continue
        
        sample_well = col_wells[0]
        
        dead_volume_to_add=ul(0)
        if sample_well.volume==ul(0):
            dead_volume_to_add = ul(dead_volume)
            
        elif sample_well.volume<ul(dead_volume):
            #add situation we don't want to deal with here
            continue
            
        
        real_dispense_volume_ul = math.floor(min(space_available(sample_well).magnitude,
                                              ul_remaining_to_fill / len(col_wells) + dead_volume_to_add.magnitude))
        
        #dispense requires a multiple of 20uL
        real_dispense_volume_ul = min(round_up(real_dispense_volume_ul,20),
                                   space_available(sample_well).magnitude)
        
        volume_of_ul_remaining = real_dispense_volume_ul - dead_volume_to_add.magnitude
        
        if volume_of_ul_remaining:
            column_volumes.append({'column': column_index, 'volume':ul(real_dispense_volume_ul)})
            
            
        ul_remaining_to_fill-=len(col_wells)*volume_of_ul_remaining
        
    if column_volumes:
        p.dispense_by_name(Reagent.dmem_fbs_ps, culture_medium_plate,column_volumes)
            
        
    for well in culture_medium_plate.all_wells(columnwise=True):
        
        if ul_remaining_to_fill <= 0:
            break        
                
        dead_volume_to_add=ul(0)
        if well.volume<ul(dead_volume):
            dead_volume_to_add = ul(dead_volume) - well.volume
        
        well_volume_to_dispense = min(space_available(well).magnitude - dead_volume_to_add.magnitude,
                                      ul_remaining_to_fill) 
        
        if well_volume_to_dispense==0:
            continue
        
        #normally out of 10ml
        wells_to_fill.append(well)
        
        volume = ul(well_volume_to_dispense) + dead_volume_to_add
        
        volumes.append(volume)
        
        ul_remaining_to_fill-=well_volume_to_dispense
        
        


    if ul_remaining_to_fill>0:
        raise Exception('unable to fulfill refill request, not enough volume in destination')

    if wells_to_fill and volumes:
        p.provision_by_name(Reagent.dmem_fbs_ps, wells_to_fill, volumes)            
    
            

def main(p, params):    
    assert isinstance(p, Protocol)
    culture_medium_plate = p.ref("culture_medium", cont_type="24-deep", storage="cold_4", discard=False)
    refill_culture_medium(p, culture_medium_plate)
    
if __name__ == '__main__':
    run(main, "PrepareStockCultureMedium")
