from __future__ import print_function
import math
from transcriptic_tools.utils import ml, ul, space_available
from transcriptic_tools.harness import run
from transcriptic_tools.custom_protocol import CustomProtocol as Protocol
from autoprotocol.protocol import Container


def refill_freeze_medium(p, stock_plate):    
    assert isinstance(p, Protocol)
    assert isinstance(stock_plate,Container)
    
    receiving_wells = stock_plate.all_wells()[:5]
    
    if not stock_plate.id:
        p.provision_by_name('FBS', receiving_wells, ml(9))
        p.provision_by_name('DMSO', receiving_wells, ml(1))
    else:
        
        wells_to_fill = []
        dmso_volumes = [] 
        fbs_volumes = []
        pennstrep_volumes = []
        
        for well in stock_plate.all_wells(columnwise=True):
            if well not in receiving_wells:
                continue
            
            well_volume_available = space_available(well).to('microliter').magnitude
            
            #normally out of 10ml
            wells_to_fill.append(well)
            dmso_volumes.append(ul(math.floor(1.0/10*well_volume_available)))
            fbs_volumes.append( ul(math.floor(9.0/10*well_volume_available)))
            
        p.provision_by_name('DMSO', wells_to_fill, dmso_volumes)
        p.provision_by_name('FBS', wells_to_fill, fbs_volumes)

            

def main(p, params):    
    assert isinstance(p, Protocol)
    stock_plate = p.ref("freeze_medium", cont_type="24-deep", storage="cold_4", discard=False)
    refill_freeze_medium(p, stock_plate)
    
if __name__ == '__main__':
    run(main, "PrepareStockFreezeMedium")
