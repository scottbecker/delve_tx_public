from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_well_max_volume,
                                      get_column_wells,
                                      copy_cell_line_name, set_property, get_volume,
                                      convert_mass_to_volume,ng )

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

def transform_spread_pick(p, source_dna_well_mass_pairs,
                          source_bacteria_well=None,
                          bacteria_type='hme63',
                          antibiotic=None,
                          second_antibiotic=None,
                          destroy_source_bacteria_tube=False,
                          add_iptg=False,
                          pick_count=2,
                          minimum_picked_colonies=1,
                          negative_control=True,
                          positive_control=True,
                          liquid_growth_time='16:hour',
                          solid_growth_time='16:hour',
                          skip_pick=False,
                          force_include_soc=False,
                          soc_medium_volume=ul(400),
                          default_transform_volume=ul(2)
                          ):
    
    assert isinstance(p,Protocol)
    
    #if no mass is specified, assume 2uL
    
    
    #figure out how much volume we should use of each source dna well
    
    source_well_lists = []
    transform_volumes = []
    
    for dna_well, dna_transfer_mass_ng in source_dna_well_mass_pairs:
        xfer_volume = convert_mass_to_volume(ng(dna_transfer_mass_ng), dna_well)
        source_well_lists.append(dna_well)
        transform_volumes.append(xfer_volume)
    
    bacteria_type_or_well = source_bacteria_well if source_bacteria_well else Reagent.from_string(bacteria_type)
    
    p.transform_spread_pick(source_well_lists, antibiotic=antibiotic, pick_count=pick_count, 
                           minimum_picked_colonies=minimum_picked_colonies, 
                           negative_control=negative_control, 
                           positive_control=positive_control, 
                           second_antibiotic=second_antibiotic, 
                           liquid_growth_time=liquid_growth_time, 
                           solid_growth_time=solid_growth_time, 
                           add_iptg=add_iptg, 
                           skip_pick=skip_pick, 
                           force_include_soc=force_include_soc, 
                           soc_medium_volume=soc_medium_volume, 
                           bacteria_type_or_well=bacteria_type_or_well, 
                           transform_volumes=transform_volumes)
    
        
    
def main(p, params):    
    """Run a serial dilution up to 10^-10 and then plate the lowest 6 concentrations on a 6 well agar plate
    """
    #bacterial protocol
    p.mammalian_cell_mode = False
    
    assert params['antibiotic']!='none_chosen','You must choose antibiotic'
    
    source_bacteria_well = None
    bacteria_type = params['bacteria_type']['value']
    if not Reagent.from_string(bacteria_type):
        source_bacteria_well = params['bacteria_type']['inputs'][bacteria_type]['bacteria_well']
    
    transform_spread_pick(p, [(pair['dna_well'], pair['dna_mass_ng']) for pair in params['source_dna_well_mass_pairs']],
                          bacteria_type=bacteria_type,
                          source_bacteria_well=source_bacteria_well,
                          antibiotic=Antibiotic.from_string(params['antibiotic']),
                          second_antibiotic=Antibiotic.from_string(params['second_antibiotic'])
                          )
    
if __name__ == '__main__':
    run(main, "TransformSpreadPick")
