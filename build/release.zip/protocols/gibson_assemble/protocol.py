from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_column_wells,
                                      copy_cell_line_name, set_property, set_well_name,
                                      get_volume)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

def gibson_assemble(p, source_bacteria_well,
                    destroy_source_tube=False):

    pass


def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False

    gibson_assemble(p, params['bacteria_tube'].well(0),
                    
                                )   

if __name__ == '__main__':
    run(main, "GibsonAssemble")
