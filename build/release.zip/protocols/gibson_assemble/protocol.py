from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_column_wells,
                                      copy_cell_line_name, set_property, set_well_name,
                                      get_volume, convert_moles_to_volume, pmol)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

def gibson_assemble(p, vector_well,
                    construct_wells,
                    product_name = 'gibson_assembly_product',
                    #clonesure antibiotic is amp
                    antibiotic=Antibiotic.amp
                    ):

    assert isinstance(p, Protocol)
    
    linearized_vector_well = p.linearize_dna(vector_well)
    
    #clonesure length
    linearized_vector_well.properties['dna_length'] = 5329
    
    #verify contruct quality and concentration
    
    for construct_well in construct_wells:
        if not construct_well.properties.get('Concentration (DNA)') or not construct_well.properties.get('A260/A280'):
            raise Exception('%s is missing Concentration (DNA) or A260/A280 property'%construct_well.name)
        
        if float(construct_well.properties['A260/A280']) <= 1.75 or float(construct_well.properties['A260/A280']) > 2.2:
            raise Exception('%s isn\'t pure enough'%construct_well.name)
            
        
    if len(construct_wells)>5:
        raise Exception('protocol doesn\'t work for more than 5 constructs')
    
    
    # run assembly reaction
    
    
    gibson_assembly_plate  = p.ref("gibson_assembly_plate",  
                                   cont_type="96-pcr", 
                                   storage=Temperature.cold_4)
    
    gibson_well = gibson_assembly_plate.well(0)
    
    
    #convert_moles_to_volume
    #use dna_length field and Concentration (DNA) properties of the plate
    
    total_reaction_volume = ul(20)
    
    vector_volume = convert_moles_to_volume(pmol(0.05), linearized_vector_well)
    
    construct_volumes = []
    total_construct_volume = ul(0)
    
    nebuilder_volume = ul(10)
    
    for construct_well in construct_wells:
        construct_volume = convert_moles_to_volume(pmol(0.05), construct_well)
        construct_volumes.append(construct_volume)
        total_construct_volume+=construct_volume
    
    water_volume = total_reaction_volume - nebuilder_volume - total_construct_volume - vector_volume
    
    if water_volume < ul(0):
        raise Exception('concentration of vector and fragments are too low to make a 20uL reaction')
    
    #
    # Combine all the Gibson reagents in one well and thermocycle
    #
    p.provision_by_name(Reagent.nebuilder_master_mix, gibson_well, nebuilder_volume)
    p.provision_by_name(Reagent.water, gibson_well, water_volume)
    
    p.transfer(linearized_vector_well,
               gibson_well, vector_volume, mix_after=True)
    
    p.transfer(construct_wells, gibson_well, construct_volumes, mix_after=True)

    assert gibson_well.volume == total_reaction_volume
    
    thermocycle_duration = "15:minute" if len(construct_wells) <= 2 else "60:minute"

    p.thermocycle(gibson_assembly_plate,
                  [{"cycles":  1, "steps": [{"temperature": "50:celsius", "duration": thermocycle_duration}]}],
                  volume=total_reaction_volume)

    #
    # Dilute assembled plasmid 4X according to the NEB Gibson assembly protocol (20ul->80ul)
    #

    p.provision_by_name(Reagent.water, gibson_well, ul(60), mix_after=True)    
    
    gibson_well.name = product_name
    
    p.transform_spread_pick(gibson_well, antibiotic, pick_count=8,
                            minimum_picked_colonies=1) 
    
    

def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False

    gibson_assemble(p, params['vector_well'],
                    params['construct_wells'],
                    params['product_name'])   

if __name__ == '__main__':
    run(main, "GibsonAssemble")
