from __future__ import print_function
from transcriptic_tools.utils import ul, ml, get_well_max_volume
from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container

from protocols.cell_maintenance_part2.protocol import split_cells

from protocols.cell_maintenance_part1.protocol import cell_maintenance, trypsonize_plate

PLATE_REQS = {
    'count':6,
    'type':'vero',
    'confluency_percent': 100
}


def main(p, params):    
    """This is the base protocol that we will send cell plates to that are left over from other experiments
    """
    pass
    
if __name__ == '__main__':
    run(main, "HSV1_Transfection")
