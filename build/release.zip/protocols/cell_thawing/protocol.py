from __future__ import print_function
from transcriptic_tools.utils import ul, ml, init_inventory_well, set_property
from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container
from protocols.cell_maintenance_part1.protocol import cell_maintenance

def main(p, params):    
    assert isinstance(p, Protocol)
    
    cells_well = params["cells_well"]
        
    init_inventory_well(cells_well)
    
    cell_line_name = cells_well.properties['cell_line_name']
    
    cell_plate = p.ref("thawed_%s_cells"%cell_line_name, cont_type="6-flat-tc", storage="warm_37",
                       cell_line_name=cell_line_name)
    
    p.provision_by_name('culture_medium', cell_plate.all_wells(), ml(3) , pre_warm_minutes=20)
    
    p.distribute(cells_well, cell_plate.all_wells(), ml(0.15),
                 mix_before=True)
    
    p.incubate(cell_plate, 'warm_37', '16:hour')
    
    p.trash_max_volume(cell_plate.all_wells())
    
    p.provision_by_name('PBS', cell_plate.all_wells(), ml(3))
    
    p.trash_max_volume(cell_plate.all_wells())
    
    p.provision_by_name('culture_medium', cell_plate.all_wells(), ml(3) )
    
    cell_maintenance(p, cell_plate, incubate_hours=2*24)
    
    
if __name__ == '__main__':
    run(main, "CellThawing")
