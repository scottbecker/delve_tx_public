from __future__ import print_function
from transcriptic_tools.utils import ul, ml, get_well_max_volume,get_cell_line_name
from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from autoprotocol.protocol import Container

from protocols.cell_maintenance_part2.protocol import split_cells

from protocols.cell_maintenance_part1.protocol import cell_maintenance, trypsonize_plate



PLATE_REQS = {
    'count':3,
    'type':'vero',
    'confluency_percent': 100
}


def main(p, params):    
    """This is the base protocol that we will send cell plates to that are left over from other experiments
    """
    assert isinstance(p, Protocol)
    
    p.mammalian_cell_mode = False
    
    #params:
    #which plate to use take cells from
    starter_cell_plate = params['cell_plate']
    cell_line_name = get_cell_line_name(starter_cell_plate)
    
    if not params.get('skip_splitting',False):
        aggregate_cells_well = p.get_10ml_well('trypsonized_cells',
                                               discard=True)
        
        trypsonize_plate(p, starter_cell_plate, aggregate_cells_well)
        
        #setup
        cell_plates = split_cells(p, aggregate_cells_well, params['cells_per_ul'],
                                  PLATE_REQS, flow_analyze=False, )
    
    else:
        cell_plates = [params['cell_plate']]
        
    #continue with normal freezing protocol. We now have 6 plates with adherent cells
    
    
    centrifuge_plate = p.ref("cell_freezing_centrifuge_plate", cont_type='96-deep-kf', 
                         discard=True)  
    
    #we need 5 96-flat wells per 6-flat well 
    
    for cell_plate in cell_plates:
        trypsonize_plate(p, cell_plate)
        for well in cell_plate.all_wells():
            p.transfer_from_well_to_plate(well, centrifuge_plate, ml(1.5), one_tip=True)
        
        
    plate_count = len(cell_plates)
    #we now have a 96-well plate with 27 wells filled with 1ml of volume
    p.spin(centrifuge_plate, '800:g', '5:minute')
    
    centrifuge_wells = centrifuge_plate.wells_from(0, plate_count*9)
    
    p.trash_max_volume(centrifuge_wells)
        
    p.provision_by_name('culture_medium', centrifuge_wells, ul(333),
                        mix_after=True)
    
    second_centrifuge_wells = centrifuge_plate.wells_from(plate_count*9, plate_count*3)
    
    dest_index = 0
    for x in range(0,plate_count*9,3):
        source_wells = centrifuge_wells[x:x+3]
        dest_well = second_centrifuge_wells[dest_index]
        p.consolidate(source_wells, dest_well, ul(333), allow_carryover=True)
        dest_index+=1
    
    p.spin(centrifuge_plate, '800:g', '5:minute')
    
    p.trash_max_volume(second_centrifuge_wells)
    
    p.provision_by_name('freeze_medium', second_centrifuge_wells, ul(666),
                        mix_after=True)
    
    cryo_vial_wells = []
    for x in range(0,plate_count*2):
        cryo_vial_wells.append(p.ref("cryo_frozen_%s_cells_%s"%(cell_line_name,x), 
                                     cont_type="screw-cap-1.8", 
                                     storage="cold_80",
                                     cell_line_name=cell_line_name).well(0))
        
    
    sources = []
    dests = []
    volumes = []
     
    #put 666uL in each cryo vial from every source   
    for i in range(0,plate_count*2):
        sources.append(second_centrifuge_wells[i])
        dests.append(cryo_vial_wells[i])
        volumes.append(ul(666))
    
    dest_index = 0
    
    #put 333uL from every source into every dest
    for source_index in range(plate_count*2,plate_count*3):
        
        sources.append(second_centrifuge_wells[source_index])
        dests.append(cryo_vial_wells[dest_index])
        volumes.append(ul(333))
        dest_index+=1
        
        sources.append(second_centrifuge_wells[source_index])
        dests.append(cryo_vial_wells[dest_index])
        volumes.append(ul(333))    
        dest_index+=1
        
    p.transfer(sources, dests, volumes, one_tip=True)
    
    
    #incubate at -20C before completing
    for cryo_well in cryo_vial_wells:
        p.incubate(cryo_well.container, 'cold_20', '12:hour', co2=0)
    
    # ----- cleanup ------

    starter_cell_plate.discard()
    for cell_plate in cell_plates:
        cell_plate.discard()
    
    
    
if __name__ == '__main__':
    run(main, "CellFreezing")
