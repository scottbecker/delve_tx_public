from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_well_max_volume,
                                      copy_cell_line_name, set_property, get_volume,
                                      get_column_wells, set_name)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

BACTERIA_TYPE_GROWTH_TIMES = {
    'hme63':{
        'OD_1': 17,
        'OD_0_point_5': 12
    }
}


def make_bacteria_chemically_competent(p, source_bacteria_well,
                                       antibiotic=None,
                                       second_antibiotic=None,
                                       bacteria_type='hme63',
                                       destroy_source_tube=False,
                                       #must be a multiple of 8 since we operate on columns
                                       tubes_to_produce=40):


    cell_line_name = get_cell_line_name(source_bacteria_well)

    assert isinstance(p,Protocol)

    assert tubes_to_produce%8==0, 'tube count must be a multiple of 8'
    assert tubes_to_produce<=48, 'max production is 48 tubes'
    
    production_column_count = tubes_to_produce/8

    if not antibiotic:
        #get the antibiotic from the source well
        well_antibiotic_str = source_bacteria_well.properties.get('antibiotic')
        if well_antibiotic_str:
            antibiotic = Antibiotic.from_string(well_antibiotic_str)
        else:
            raise Exception('Source Well must have property \'antibiotic\' set if antibiotic not specified')

    assert isinstance(antibiotic,Antibiotic)

    assert antibiotic!=second_antibiotic, "can't add the same antibiotic twice"


    assert bacteria_type in BACTERIA_TYPE_GROWTH_TIMES, 'unknown bacteria type %s'%bacteria_type
    
    growth_plate = p.ref('growth_plate', cont_type="96-deep", discard=True)
    od1_growth_wells = get_column_wells(growth_plate, 0)
    
    set_name(od1_growth_wells,'od 1.0 growth well')
   
    def add_antibiotic(wells, broth_volume):
       
        p.add_antibiotic(wells, antibiotic,
                         total_volume_to_add_including_broth=broth_volume)
        
        if second_antibiotic:
            p.add_antibiotic(wells, second_antibiotic)        
            
    add_antibiotic(od1_growth_wells, ul(1980))
            
    p.distribute(source_bacteria_well, od1_growth_wells, 
                 min(ul(20), get_volume(source_bacteria_well,aspiratable=True)/len(od1_growth_wells)),
                 allow_carryover=True)
    
    bacteria_growth_hours = BACTERIA_TYPE_GROWTH_TIMES[bacteria_type]
    
    p.incubate(growth_plate, Temperature.warm_37, '%s:hours'%bacteria_growth_hours['OD_1'],shaking=True)

    p.measure_bacterial_density(od1_growth_wells,"goal_OD_1_0")

    od_0_point_5_growth_wells = get_column_wells(growth_plate, range(1,1+production_column_count))
    
    set_name(od_0_point_5_growth_wells,'od 0.5 growth well')
    add_antibiotic(od_0_point_5_growth_wells, ml(1))

    for dest_col_index in range(1,6):
        p.transfer_column(growth_plate, 0, growth_plate, 
                         dest_col_index, ul(200))
    
    p.incubate(growth_plate, Temperature.warm_37, '%s:hours'%bacteria_growth_hours['OD_0_point_5'],shaking=True)
    
    p.incubate(growth_plate, Temperature.cold_4, '20:minutes', shaking=False)
    
    cold_incubate_instruction = p.get_instruction_index()
    
    p.spin(growth_plate, '4000:g', '3:minutes')
    
    trash_wells = get_column_wells(growth_plate, range(7,7+production_column_count))
    
    assert len(trash_wells) == len(od_0_point_5_growth_wells), 'different number of trash wells from od 0.5 wells'
    
    set_name(trash_wells,'trash_well')

    p.transfer(od_0_point_5_growth_wells, trash_wells, get_volume(od_0_point_5_growth_wells[0],
                                                                  aspiratable=True), one_tip=True)
    
    provision_tss_instruction = p.get_instruction_index()+1
    
    p.provision_by_name(Reagent.tss,od_0_point_5_growth_wells,ul(200),
                        mix_after=True,repetitions=20)
    
    p.add_time_constraint({"mark": cold_incubate_instruction, "state": "end"},
                          {"mark": provision_tss_instruction, "state": "end"}, 
                          '10:minute')
    
    #use stamp to mix quickly
    p.stamp(od_0_point_5_growth_wells[0], 
            od_0_point_5_growth_wells[0],
            ul(0),
            shape={'rows':8, 'columns':production_column_count},
            mix_before=True,
            repetitions=20)
    
    p.incubate(growth_plate, Temperature.cold_4, '20:minutes', shaking=False,
               human=True)
    
    cold_incubate_instruction = p.get_instruction_index()
    
    cryo_vial_wells = []
    for i, comp_cell_well in enumerate(od_0_point_5_growth_wells):
        cryo_well = p.ref("cryo_frozen_%s_chem_competent_cells_%s"%(cell_line_name,i), 
                          cont_type="micro-2.0", 
                          storage="cold_80",
                          cell_line_name=cell_line_name).well(0)
        
        p.flash_freeze(cryo_well.container, '2:seconds')
        p.transfer(comp_cell_well, cryo_well, get_volume(comp_cell_well, 
                                                        aspiratable=True))

        p.flash_freeze(cryo_well.container, '15:seconds')
        
        flash_freeze_instruction_index = p.get_instruction_index()
        
        p.add_time_constraint({"mark": cold_incubate_instruction, "state": "end"},
                              {"mark": flash_freeze_instruction_index, "state": "end"}, 
                              '10:minute')        
    
        set_property(cryo_well,'antibiotic',antibiotic.name)

   
    if destroy_source_tube:

        source_bacteria_well.container.discard()



def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False

    make_bacteria_chemically_competent(p, params['bacteria_well'],
                                       Antibiotic.from_string(params['antibiotic']) if params['antibiotic'] != 'cell_line' else None,
                                       second_antibiotic=Antibiotic.from_string(params['second_antibiotic']) if params['second_antibiotic'] != 'cell_line' else None,
                                       destroy_source_tube=params['destroy_source_tube'],
                                       bacteria_type=params['bacteria_type']
                                       )

if __name__ == '__main__':
    run(main, "MakeBacteriaChemicallyCompetent")
