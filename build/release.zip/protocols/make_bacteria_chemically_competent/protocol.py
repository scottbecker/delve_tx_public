from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_well_max_volume,
                                      copy_cell_line_name, set_property, get_volume,
                                      get_column_wells)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

BACTERIA_TYPE_GROWTH_TIMES = {
    'hme63':{
        'OD_1': 17,
        'OD_0_point_5': 12
    }
}


def make_bacteria_chemically_competent(p, source_bacteria_well,
                                       antibiotic=None,
                                       second_antibiotic=None,
                                       bacteria_type='hme63',
                                       destroy_source_tube=False):

    cell_line_name = get_cell_line_name(source_bacteria_well)

    assert isinstance(p,Protocol)

    if not antibiotic:
        #get the antibiotic from the source well
        well_antibiotic_str = source_bacteria_well.properties.get('antibiotic')
        if well_antibiotic_str:
            antibiotic = Antibiotic.from_string(well_antibiotic_str)
        else:
            raise Exception('Source Well must have property \'antibiotic\' set if antibiotic not specified')

    assert isinstance(antibiotic,Antibiotic)

    assert antibiotic!=second_antibiotic, "can't add the same antibiotic twice"


    assert bacteria_type in BACTERIA_TYPE_GROWTH_TIMES, 'unknown bacteria type %s'%bacteria_type
    
    growth_plate = p.ref('growth_plate', cont_type="96-deep", discard=True)
    od1_growth_wells = get_column_wells(growth_plate, 0)
    
    for well in od1_growth_wells:
        well.name = 'od 1.0 growth well'
   
    def add_antibiotic(wells, broth_volume):
       
        p.add_antibiotic(wells, antibiotic,
                         total_volume_to_add_including_broth=broth_volume)
        
        if second_antibiotic:
            p.add_antibiotic(wells, second_antibiotic)        
            
    add_antibiotic(od1_growth_wells, ul(1980))
            
    p.distribute(source_bacteria_well, od1_growth_wells, ul(20), allow_carryover=True)
    
    bacteria_growth_hours = BACTERIA_TYPE_GROWTH_TIMES[bacteria_type]
    
    p.incubate(growth_plate, Temperature.warm_37, '%s:hours'%bacteria_growth_hours['OD_1'],shaking=True)

    p.measure_bacterial_density(od1_growth_wells,"goal_OD_1_0")

    od_0_point_5_growth_wells = get_column_wells(growth_plate, range(1,6))

    for well in od_0_point_5_growth_wells:
        well.name = 'od 0.5 growth well'    

    add_antibiotic(od_0_point_5_growth_wells, ml(1))

    for dest_col_index in range(1,6):
        p.transfer_column(growth_plate, 0, growth_plate, 
                         dest_col_index, ul(200))
    
    p.incubate(growth_plate, Temperature.warm_37, '%s:hours'%bacteria_growth_hours['OD_0_point_5'],shaking=True)
    
    p.incubate(growth_plate, Temperature.cold_4, '20:minutes', shaking=False)
    
    p.spin(growth_plate, '4000:g', '3:minutes')
    
    
    
    copy_cell_line_name(source_bacteria_well, cryo_vial_wells)
    set_property(cryo_vial_wells,'antibiotic',antibiotic.name)

    p.distribute(mix_well2, cryo_vial_wells, ul(115), allow_carryover=True)

    if destroy_source_tube:

        source_bacteria_well.container.discard()



def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False

    make_bacteria_chemically_competent(p, params['bacteria_well'],
                                       Antibiotic.from_string(params['antibiotic']) if params['antibiotic'] != 'cell_line' else None,
                                       second_antibiotic=Antibiotic.from_string(params['second_antibiotic']) if params['second_antibiotic'] != 'cell_line' else None,
                                       destroy_source_tube=params['destroy_source_tube'],
                                       bacteria_type=params['bacteria_type']
                                       )

if __name__ == '__main__':
    run(main, "MakeBacteriaChemicallyCompetent")
