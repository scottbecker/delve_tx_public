from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_well_max_volume,
                                      copy_cell_line_name, set_property, get_volume,
                                      get_column_wells, set_name)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

BACTERIA_TYPE_GROWTH_TIMES = {
    'hme63':{
        'OD_1': 17,
        'OD_0_point_5': 12
    }
}


def make_bacteria_chemically_competent(p, source_bacteria_well,
                                       antibiotic=None,
                                       second_antibiotic=None,
                                       bacteria_type='hme63',
                                       destroy_source_tube=False,
                                       #must be a multiple of 8 since we operate on columns
                                       tubes_to_produce=24):


    cell_line_name = get_cell_line_name(source_bacteria_well)

    assert isinstance(p,Protocol)

    assert tubes_to_produce%8==0, 'tube count must be a multiple of 8'
    assert tubes_to_produce<=32, 'max production is 32 tubes'
    
    production_column_count = tubes_to_produce/8

    if not antibiotic:
        #get the antibiotic from the source well
        well_antibiotic_str = source_bacteria_well.properties.get('antibiotic')
        if well_antibiotic_str:
            antibiotic = Antibiotic.from_string(well_antibiotic_str)
        else:
            raise Exception('Source Well must have property \'antibiotic\' set if antibiotic not specified')

    assert isinstance(antibiotic,Antibiotic)

    assert antibiotic!=second_antibiotic, "can't add the same antibiotic twice"


    assert bacteria_type in BACTERIA_TYPE_GROWTH_TIMES, 'unknown bacteria type %s'%bacteria_type
    
    growth_plate = p.ref('growth_plate', cont_type="96-deep", discard=True)
    chill_plate = p.ref('chill_plate', cont_type="96-deep", discard=True)
    
    od1_growth_column = 2
    od1_growth_wells = get_column_wells(growth_plate, od1_growth_column)
    
    od_0_point_5_start_column = 3
    
    od_0_point_5_growth_wells = get_column_wells(growth_plate, range(od_0_point_5_start_column,
                                                                     od_0_point_5_start_column+production_column_count))
    
    cold_bacteria_wells = chill_plate.wells(od_0_point_5_growth_wells.indices())
    
    set_name(od1_growth_wells,'od 1.0 growth well')
    
    water_wells = get_column_wells(chill_plate, [0,1,2] + range(od_0_point_5_start_column + production_column_count,12))
    
    #fill the leftover wells with water to help the plate stay colder longer
    p.provision_by_name(Reagent.water, water_wells, ml(1.8))      
    
    set_name(water_wells,'water_well')
    
    p.incubate(chill_plate, Temperature.cold_4, '6:hour', shaking=False)
    
    incubate_chill_plate_index = p.get_instruction_index()
    
    def add_antibiotic(wells, broth_volume):
       
        p.add_antibiotic(wells, antibiotic,
                         total_volume_to_add_including_broth=broth_volume)
        
        if second_antibiotic:
            p.add_antibiotic(wells, second_antibiotic)        
            
    #fill wells to 50% to maximize growth
    add_antibiotic(od1_growth_wells, ul(1000))
            
    p.distribute(source_bacteria_well, od1_growth_wells, 
                 min(ul(20), get_volume(source_bacteria_well,aspiratable=True)/len(od1_growth_wells)),
                 allow_carryover=True)
    
    bacteria_growth_hours = BACTERIA_TYPE_GROWTH_TIMES[bacteria_type]
    
    p.incubate(growth_plate, Temperature.warm_37, '%s:hour'%bacteria_growth_hours['OD_1'],shaking=True)

    p.measure_bacterial_density(od1_growth_wells,"goal_OD_1_0")
    
    set_name(od_0_point_5_growth_wells,'od 0.5 growth well')
    add_antibiotic(od_0_point_5_growth_wells, ml(1))

    p.transfer_column(growth_plate, od1_growth_column, growth_plate, 
                      range(od_0_point_5_start_column,od_0_point_5_start_column+production_column_count),
                      ul(200), one_tip=True)
    
    p.incubate(growth_plate, Temperature.warm_37, '%s:hour'%bacteria_growth_hours['OD_0_point_5'],shaking=True)
    
    p.transfer(od_0_point_5_growth_wells, cold_bacteria_wells, get_volume(od_0_point_5_growth_wells[0],aspiratable=True), one_tip=True,
               mix_before=True)
    
    p.incubate(chill_plate, Temperature.cold_4, '1:hour', shaking=False)
    
    cold_incubate_instruction = p.get_instruction_index()
    
    p.spin(chill_plate, '4000:g', '3:minute')
    
    #trash the supernatant 
    p.transfer(cold_bacteria_wells, od_0_point_5_growth_wells, get_volume(cold_bacteria_wells[0],
                                                                          aspiratable=True), one_tip=True,
               mix_before=False)
    
    provision_tss_instruction = p.get_instruction_index()+1
    
    p.provision_by_name(Reagent.tss,cold_bacteria_wells,ul(200),
                        mix_after=False)
    
    #@TODO: update this constraint based on fridge experiment
    p.add_time_constraint({"mark": cold_incubate_instruction, "state": "end"},
                          {"mark": provision_tss_instruction, "state": "end"}, 
                          '10:minute')
    
    #use stamp to re-suspend quickly
    p.stamp(cold_bacteria_wells[0], 
            cold_bacteria_wells[0],
            ul(100),
            shape={'rows':8, 'columns':production_column_count},
            mix_before=True,
            one_tip=True,
            repetitions=19)
    
    cold_tss_instruction = p.get_instruction_index()
    
    cryo_vial_wells = []
    for i, comp_cell_well in enumerate(cold_bacteria_wells):
        cryo_well = p.ref("cryo_frozen_%s_chem_competent_cells_%s"%(cell_line_name,i), 
                          cont_type="micro-1.5", 
                          storage="cold_80",
                          cell_line_name=cell_line_name).well(0)
        
        #p.flash_freeze(cryo_well.container, '10:second')
        p.transfer(comp_cell_well, cryo_well, get_volume(comp_cell_well, 
                                                        aspiratable=True))
        
        transfer_instruction_index = p.get_instruction_index()

        p.flash_freeze(cryo_well.container, '10:second')
        
        flash_freeze_instruction_index = p.get_instruction_index()
        
        p.add_time_constraint({"mark": transfer_instruction_index, "state": "start"},
                              {"mark": flash_freeze_instruction_index, "state": "end"}, 
                              '10:second')              
        
        p.add_time_constraint({"mark": cold_tss_instruction, "state": "end"},
                              {"mark": flash_freeze_instruction_index, "state": "end"}, 
                              #@TODO: update this constraint based on fridge experiment
                              '10:minute')        
    
        set_property(cryo_well,'antibiotic',antibiotic.name)

   
    if destroy_source_tube:

        source_bacteria_well.container.discard()



def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False

    make_bacteria_chemically_competent(p, params['bacteria_well'],
                                       Antibiotic.from_string(params['antibiotic']) if params['antibiotic'] != 'cell_line' else None,
                                       second_antibiotic=Antibiotic.from_string(params['second_antibiotic']) if params['second_antibiotic'] != 'cell_line' else None,
                                       destroy_source_tube=params['destroy_source_tube'],
                                       bacteria_type=params['bacteria_type'],
                                       tubes_to_produce=params['tubes_to_produce']
                                       )

if __name__ == '__main__':
    run(main, "MakeBacteriaChemicallyCompetent")
