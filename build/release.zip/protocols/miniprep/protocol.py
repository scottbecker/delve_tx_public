from __future__ import print_function
from transcriptic_tools.utils import (ul, ml, get_cell_line_name, get_well_max_volume,
                                      copy_cell_line_name, set_property, get_volume)

from transcriptic_tools.harness import run
from transcriptic_tools import CustomProtocol as Protocol
from transcriptic_tools.enums import Antibiotic, Reagent, Temperature

def miniprep(p, source_bacteria_well,
             antibiotic=None,
             destroy_source_tube=False,
             incubate_hours=24,
             measure_od=True):
    
    cell_line_name = get_cell_line_name(source_bacteria_well)
    
    assert isinstance(p,Protocol)
    
    if not antibiotic:
        #get the antibiotic from the source well
        well_antibiotic_str = source_bacteria_well.properties.get('antibiotic')
        if well_antibiotic_str:
            antibiotic = Antibiotic.from_string(well_antibiotic_str)
        else:
            raise Exception('Source Well must have property \'antibiotic\' set if antibiotic not specified')
    
    assert isinstance(antibiotic,Antibiotic)
    
    # Tubes and plates
    growth_plate = p.ref('growth_plate', cont_type="96-deep", discard=True)
    growth_well = growth_plate.well(0)
    
    miniprep_result_plate = p.ref('minipreped_%s'%source_bacteria_well.name, cont_type="96-pcr", storage=Temperature.cold_4)
    miniprep_result_well = miniprep_result_plate.well(0)
    
    p.transfer(source_bacteria_well,growth_well,ul(50),mix_before=True)
    
    #adding antibiotic mixes after by default
    p.add_antibiotic(growth_well, antibiotic, broth_volume=ul(1930))
 
    p.incubate(growth_plate, "warm_37", "{}:hour".format(incubate_hours), shaking=True)
    
    if measure_od:
        p.measure_bacterial_density(growth_well)
    
    p.miniprep(growth_well,miniprep_result_well)
    
    p.measure_concentration(miniprep_result_well, "dna concentration", 'DNA')
    
    if destroy_source_tube:
        
        source_bacteria_well.container.discard()
    
    

def main(p, params):    
    """This protocol takes a tube of bacteria, amplifies it, and creates/stores new tubes of frozen cells
    """
    #bacterial protocol
    p.mammalian_cell_mode = False
    
    miniprep(p, params['bacteria_well'],
             Antibiotic.from_string(params['antibiotic']) if params['antibiotic'] != 'cell_line' else None,
             params['destroy_source_tube'],
             params['incubate_hours'],
             params['measure_od']
             )
    
if __name__ == '__main__':
    run(main, "Miniprep")
