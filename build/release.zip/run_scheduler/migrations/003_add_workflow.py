from __future__ import print_function
from run_scheduler.model import init_db_connection, Protocol, database_proxy, Run
from run_scheduler import model
from playhouse.migrate import *
import os

def migrate_db():
    
    
    migrator = SqliteMigrator(database_proxy)    
    
    depends_on_run = ForeignKeyField(Run, related_name='dependent_run',
                                     on_delete='CASCADE',
                                     to_field=Run.id,
                                     unique=True,
                                     null=True)

    workflow_name = CharField(null=True)
    
    with model.database_proxy.atomic() as txn:
        migrate(
            migrator.add_column('run', 'depends_on_run_id', depends_on_run),
            migrator.add_column('run', 'workflow_name', workflow_name),
        )      
                
          
def main():
    init_db_connection('transcriptic_real')
    migrate_db()
    init_db_connection('transcriptic_test')
    migrate_db()    
    
    
if __name__ == '__main__':
    main()