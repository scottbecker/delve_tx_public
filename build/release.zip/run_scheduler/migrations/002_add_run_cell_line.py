from __future__ import print_function
from run_scheduler.model import init_db_connection, Protocol, database_proxy, Run
from run_scheduler import model
from playhouse.migrate import *
import os

def migrate_db():
    
    
    migrator = SqliteMigrator(database_proxy)    
    
    cell_line_name = CharField(index=True,null=True)
    
    with model.database_proxy.atomic() as txn:
        migrate(
            migrator.add_column('run', 'cell_line_name', cell_line_name),
        )    
    
        runs = Run.select()
    
        for run in runs:
            run.cell_line_name = 'vero'
            run.save()
        
        migrate(
            migrator.add_not_null('run', 'cell_line_name'),
        )              
                
          
def main():
    init_db_connection('transcriptic_real')
    migrate_db()
    init_db_connection('transcriptic_test')
    migrate_db()    
    
    
if __name__ == '__main__':
    main()