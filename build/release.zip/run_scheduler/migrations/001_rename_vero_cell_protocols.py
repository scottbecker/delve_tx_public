from __future__ import print_function
from run_scheduler.model import init_db_connection, Protocol
from run_scheduler import model
import os

def migrate_db():
    with model.database_proxy.atomic() as txn:
        protocols_to_rename = Protocol.select().where(Protocol.name % '*VeroCell*' )
    
        for protocol in protocols_to_rename:
            protocol.name = protocol.name.replace('VeroCell','Cell')
            protocol.save()
        
def main():
    init_db_connection('transcriptic_real')
    migrate_db()
    init_db_connection('transcriptic_test')
    migrate_db()    
    
    
if __name__ == '__main__':
    main()