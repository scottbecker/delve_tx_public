from model import init_db_connection, Protocol
import sys

#this class can't be inside model.py because it uses run_scheduler that imports model

def add_protocol(name,transcriptic_id):
    Protocol.create(name=name,transcriptic_id=transcriptic_id,
                    is_terminal=True)    

if __name__=='__main__':
    
    init_db_connection('transcriptic_real')
    add_protocol(sys.argv[1],sys.argv[2])
    
    init_db_connection('transcriptic_test')
    add_protocol(sys.argv[1],sys.argv[2])