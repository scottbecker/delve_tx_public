from model import init_db_connection, create_db
from run_scheduler import RunScheduler
import os

#this class can't be inside model.py because it uses run_scheduler that imports model

if __name__=='__main__':
    #init_db_connection(sys.argv[1])
    #create_db()
    
    try:
        os.remove('real_run_scheduler.db')
    except OSError as e:
        if 'No such file' not in str(e):
            raise
    
    try:
        os.remove('test_run_scheduler.db')
    except OSError as e:
        if 'No such file' not in str(e):
            raise

    
    init_db_connection('transcriptic_real')
    create_db()
    
    init_db_connection('transcriptic_test')
    create_db()    
    
       
    #run_scheduler = RunScheduler(test_mode=True)
    #run_scheduler.init_thawing('r19823q3gwttu')    