from model import (init_db_connection, Run, WellOrContainer, Protocol)
import run_scheduler
from model import WellOrContainer
from run_scheduler import RunScheduler
from lib import setup_logging
import model
import sys


from run_scheduler import update_protocol_transcriptic_ids



setup_logging('logging.json')
init_db_connection('transcriptic_real')

update_protocol_transcriptic_ids()

#rs = RunScheduler(False, analyze_only=True)
rs = RunScheduler(False, analyze_only=False)

#c = WellOrContainer()
#c.container_transcriptic_id = 'ct19dgz4ds43gq'
#c.cells_per_ul = 400
#c.save()

c = WellOrContainer.select().where(WellOrContainer.id == 20).get()

#c.id
#rs.submit_pending_runs([c])
#rs.dequeue_runs(len([c]))
#rs.dequeue_runs(len([c])).get()
#rs.dequeue_runs(len([c])).get()

#print rs.dequeue_runs(len([c])).get().protocol.name

#sys.exit()


with model.database_proxy.atomic() as txn:
    rs.submit_pending_runs([c])
    #txn.rollback()
