from __future__ import print_function
import json
from transcriptic_tools.custom_connection import CustomConnection as Connection
from transcriptic.objects import Container, Run
import json
api = Connection.from_file(".transcriptic")

from model import init_db_connection, Protocol
import os



#this class can't be inside model.py because it uses run_scheduler that imports model

def update_protocol_transcriptic_ids():

    transcriptic_protocols = api.protocols()
    
    transcriptic_protoocol_lookup = {}
    
    for protocol in transcriptic_protocols:
        transcriptic_protoocol_lookup[protocol['name']] = protocol
        
    
    for protocol in Protocol.select():
        protocol.transcriptic_id = transcriptic_protoocol_lookup[protocol.name]['id']
        protocol.save()
        
    

if __name__=='__main__':

    init_db_connection('transcriptic_real')
    update_protocol_transcriptic_ids()
    
    init_db_connection('transcriptic_test')
    update_protocol_transcriptic_ids()