from __future__ import print_function
import json
from transcriptic.config import Connection
from transcriptic.objects import Container, Run
#from autoprotocol import Protocol
import json
api = Connection.from_file(".transcriptic")

run = Run('r199auwhwnyww')
#print(json.dumps(run.attributes))
#p = Protocol()
#container = p.ref(c.name, c.id, c.container_type.shortname, c.storage, cover=c.cover)

datasets = api.datasets('p18v89yurexft','r192cujcwmrru') 
print(datasets)
