import json
import model
from model import Run, Protocol
from transcriptic_tools.custom_connection import CustomConnection as Connection


class WorkflowBase(object):
    def __init__(self, cell_line_name, priority, input_json=None):
        self.cell_line_name = cell_line_name
        self.input_json = input_json
        self.priority = priority    

class HSV1TransfectionLowDNAMass(WorkflowBase):
    """
    
    This workflow schedules a run of HSV1Transfection followed by 3 VirusInfections
    
    """
    
    @staticmethod
    def on_run_complete(completed_run, api):
        from run_scheduler import BSL2_PROJECT_ID
        
        #set the output of this run to be the input for the next run
        
        next_run = completed_run.dependent_run
        
        if not next_run:
            return
        
        #we shouldn't have to do this if pewee was built correctly
        next_run = next_run.get()
        
        #get the output containers from the api
        
        assert isinstance(api,Connection)
        
        #find the output virus container
        
        output_containers = api.get_output_containers(BSL2_PROJECT_ID, completed_run.transcriptic_id,
                                                      completed_run.protocol.id)
        
        output_virus_containers = [container for container in output_containers if '_virus_' in container['name']]
        
        if not output_virus_containers:
            return
        
        assert len(output_virus_containers)==1,'There should only be out output virus container from run %s'%completed_run.transcriptic_id
        
        #there should only be one
        output_container_id = output_virus_containers[0]['container_id']
        
        input_json = next_run.get_input_json_as_obj()
        
        input_json['virus_wells'] = [{"containerId": output_container_id, "wellIndex": 0}]
        
        next_run.set_input_json(input_json) 
        next_run.save()
        
    def schedule_runs(self):
       
        input_json = self.input_json.copy()
        
        input_json['flash_freeze'] = True
        input_json['well_count'] = 1
        
        
        transfection_run = Run(protocol = Protocol.get_by_name('HSV1Transfection'),
                               priority = self.priority,          
                               cell_line_name = self.cell_line_name,
                               input_json = json.dumps(input_json,indent=4),
                               workflow_name='HSV1TransfectionLowDNAMass')

        transfection_run.save()
        
        #@TODO: update submit run for previous to set the output container to be the input of 
        #the dependent runs
        
        infection_run1 = Run(protocol = Protocol.get_by_name('VirusInfection'),
                             priority = self.priority,          
                             cell_line_name = self.cell_line_name,
                             depends_on_run = transfection_run,
                             workflow_name='HSV1TransfectionLowDNAMass'
                             )
        infection_run1.set_input_json({'well_count':1,
                                       'flash_freeze':True})
              
        infection_run1.save()
        
        infection_run2 = Run(protocol = Protocol.get_by_name('VirusInfection'),
                             priority = self.priority,          
                             cell_line_name = self.cell_line_name,
                             depends_on_run = infection_run1,
                             workflow_name='HSV1TransfectionLowDNAMass'
                             )
        
        #Here we add a negative control and plaque stain to see if we are getting plaques
        infection_run2.set_input_json({'well_count':1,
                                       'flash_freeze':False,
                                       'negative_control':True,
                                       'plaque_stain':True})
    
        infection_run2.save()      
        
        infection_run3 = Run(protocol = Protocol.get_by_name('VirusInfection'),
                             priority = self.priority,          
                             cell_line_name = self.cell_line_name,
                             depends_on_run = infection_run2,
                             workflow_name='HSV1TransfectionLowDNAMass'
                             )
        infection_run3.set_input_json({'well_count':6,
                                       'flash_freeze':True})
    
        infection_run3.save()         


