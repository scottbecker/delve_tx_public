from __future__ import print_function
import datetime
import math
import json
import sys
import traceback
from peewee import *
import os

database_proxy = Proxy()

class CustomModel(Model):
    def __repr__(self):
        return str(self.__dict__)
    
    def __str__(self):
        return self.__repr__()    

class Protocol(CustomModel):
    id = PrimaryKeyField()
    transcriptic_id = CharField()
    name = CharField(index=True)
    is_terminal= BooleanField()
    initial_post = TextField(null=True)


    created_at = DateTimeField(constraints=[SQL("DEFAULT (datetime('now'))")])

    @staticmethod
    def get_by_name(name):
        return Protocol.select().where(Protocol.name==name).get()

    class Meta:
        database = database_proxy # this model uses the "people.db" database
        

class Run(CustomModel):
    id = PrimaryKeyField()
    priority = IntegerField()
    transcriptic_id = CharField(index=True, null=True)
    protocol = ForeignKeyField(Protocol, related_name='runs',
                                  on_delete='CASCADE')
    
    input_json = TextField(null=True)
    
    analysis_json = TextField(null=True)
    
    #this is the time at which it was made locally (before sending to transcriptic)
    #created_at = DateTimeField(default=datetime.datetime.now)
    created_at = DateTimeField(constraints=[SQL("DEFAULT (datetime('now'))")])
    
    cell_line_name = CharField(index=True)
    
    #this corresponds to what Transcriptic considers created_at
    submitted_at = DateTimeField(null=True)
    completed_at = DateTimeField(null=True)
    canceled_at = DateTimeField(null=True)
    
    depends_on_run = ForeignKeyField('self', related_name='dependent_run',
                                     on_delete='CASCADE',
                                     unique=True,
                                     null=True)
    
    workflow_name = CharField(null=True)
    
    
    def get_input_json_as_obj(self):
        return json.loads(self.input_json)
    
    def set_input_json(self,input_json_obj):
        if isinstance(input_json_obj,str):
            self.input_json = input_json_obj
        else:
            self.input_json = json.dumps(input_json_obj, indent=4)
    
    class Meta:
        database = database_proxy # This model uses the "people.db" database.

class WellOrContainer(CustomModel):
        id = PrimaryKeyField()
        container_transcriptic_id = CharField(index=True)
        well_index = IntegerField(null=True)
        
        cells_per_ul = IntegerField(null=True)
        
        created_at = DateTimeField(constraints=[SQL("DEFAULT (datetime('now'))")])
        
        def is_well(self):
            return self.well_index!=None
    
    
        input_to_run = ForeignKeyField(Run, null=True,
                                    related_name='input_wellorcontainer',
                                    on_delete='CASCADE')
        
        
        output_of_run = ForeignKeyField(Run, null=True,
                                     related_name='output_wellorcontainers',
                                     on_delete='CASCADE')
    
        def update_cell_concentration(self, cells_in_test_sample,
                                      volume_of_test_sample):
            
            cells_per_ul = cells_in_test_sample / volume_of_test_sample.to('microliter').magnitude
            
            self.cells_per_ul = math.floor(cells_per_ul)
            self.save()
    
        @staticmethod
        def create_from_transcriptic_refs(starts_with_str,refs):
            well = WellOrContainer()
            
            trx_wells = list(filter(lambda ref: ref['name'].startswith(starts_with_str),
                                         refs))
            
            #we may not always find the starts_with_str
            if not trx_wells:
                return None
            
            trx_well = trx_wells[0]
            well.container_transcriptic_id = trx_well['container_id']
            
            
            return well               
    
        class Meta:
            database = database_proxy # this model uses the "people.db" database

def create_db():
    global database_proxy
    database_proxy.connect()    
    database_proxy.create_tables([Protocol, Run, WellOrContainer])
    
    Protocol.create(name='CellThawing',transcriptic_id='pr197mfyszva4b',
                    is_terminal=False)
    
    Protocol.create(name='CellSplitting',transcriptic_id='pr197mfyt3m6vw',
                    is_terminal=False,
                    initial_post='One or more runs will imediately follow this run that must be started '+\
                        'within 1 hour of this run finishing. Please do not schedule this run to finish close '+\
                        'to the end of business.')
    
    Protocol.create(name='CellFreezing',transcriptic_id='pr197mfyt5d6sh',
                    is_terminal=True)
    
    Protocol.create(name='HSV1Transfection',transcriptic_id='pr198c3xtt35d5',
                    is_terminal=True,
                    initial_post = 'Please do not provision Lipofectamine (rs196bb7qetqmr) faster than 100:microliter/second. '+\
                    'This is to prevent merging of liposomes.')   
    
    Protocol.create(name='VirusTitration',transcriptic_id='pr198cd24nsszf',
                    is_terminal=True,
                    )     
    
    Protocol.create(name='VirusInfection',transcriptic_id='pk196utxd8cpph',
                    is_terminal=True,
                    )         
    
    

def init_db_connection(environment='transcriptic_test'):
    global database_proxy
    
    if environment == 'transcriptic_test':
        database = SqliteDatabase('test_run_scheduler.db')
    elif environment == 'transcriptic_real':
        database = SqliteDatabase('real_run_scheduler.db')   
    elif environment == 'unittest':
        database = SqliteDatabase(':memory:') 
    else:
        raise Exception('unknown database type %s, used one of %s'%(environment,['transcriptic_test',
                                                                                 'transcriptic_real',
                                                                                 'unittest']))
        
    database_proxy.initialize(database)
    
    if environment=='unittest':
        create_db()

