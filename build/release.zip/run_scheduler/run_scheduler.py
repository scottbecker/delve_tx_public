from __future__ import print_function
import argparse
import tempfile
import shutil
import inspect
import sys
import datetime
from time import sleep
import json
import os
from builtins import filter
from peewee import fn
from model import (init_db_connection, Run, WellOrContainer, Protocol)
import model
from transcriptic_tools.custom_connection import CustomConnection as Connection
import transcriptic
from transcriptic_tools.utils import ul
from protocols.cell_maintenance_part1.protocol import FLOW_TEST_SAMPLE_VOLUME
from lib.flow_analyze import get_cell_count
from update_protocol_ids import update_protocol_transcriptic_ids
from lib import setup_logging
import workflow

import requests
requests.packages.urllib3.disable_warnings()

PROJECT_ID = 'p18r6kqqxhehn'

BSL2_PROJECT_ID = PROJECT_ID

BSL1_PROJECT_ID = 'p19aqhcbep8ea'

BSL1_PROTOCOLS = {
                  }  

MAX_SPLITTING_PLATE_COUNT = 1

CELL_COUNT_OVERRIDE = None #390


class RunScheduler(object):
   
   def __init__(self, test_mode, fake_get_cells_in_test_sample=None,
                analyze_only = False):
      self.test_mode = test_mode
      self.analyze_only = analyze_only
      self.api = Connection.from_file(".transcriptic")
      self.api.analyze_only = self.analyze_only
      self.api.test_mode = self.test_mode
      #needed since test mode doesn't actually create data
      self.fake_get_cells_in_test_sample = fake_get_cells_in_test_sample
      self.max_splitting_plate_count = MAX_SPLITTING_PLATE_COUNT
   
   def sync(self, input_params = None):
      with model.database_proxy.atomic() as txn:
         #find Runs that are not complete
         
         
         incomplete_runs = list(Run.select().join(Protocol).where(Run.completed_at.is_null(True),
                                                                  Run.submitted_at.is_null(False)))
         
         if not incomplete_runs:
            return
         
         #check if the runs are complete with Transcriptc
         
         for incomplete_run in incomplete_runs:
            assert isinstance(incomplete_run,Run)
            
            transcriptic_run = transcriptic.Run(incomplete_run.transcriptic_id)
            if transcriptic_run.attributes.get('completed_at'):
               
               completed_run = incomplete_run

               #update their status       
               
               completed_run.completed_at = transcriptic_run.attributes['completed_at']
               
               #update our output wells with cell concentration information
               
               cells_in_test_sample = self._get_cells_in_test_sample(transcriptic_run, completed_run.cell_line_name)
               
               for well in completed_run.output_wellorcontainers:
                  well.update_cell_concentration(cells_in_test_sample, FLOW_TEST_SAMPLE_VOLUME)
                
               completed_run.save()
               
               #notify the run's workflow that the run is complete (updates downstream runs with needed info)
               
               if len(completed_run.dependent_run)>0 and completed_run.workflow_name:
                  getattr(workflow, completed_run.workflow_name).on_run_complete(completed_run, self.api)
                  
               
               #if any of the completed runs are non-terminal, kick-off new runs (including one splitting run)
               if not completed_run.protocol.is_terminal:
                  self._kickoff_downstream_runs(completed_run, input_params=input_params)
            
         #we don't store any changes when in analysis mode      
         if self.analyze_only:
            txn.rollback()
            
   def _get_cells_in_test_sample(self, transcriptic_run, cell_line_name):
      """ Download flow analysis results from a run and return the cells_per_well data """
      
      if self.fake_get_cells_in_test_sample:
         return self.fake_get_cells_in_test_sample
      
      #download the fcs file from transcriptic
      
      try:
         datasets = self.api.datasets(PROJECT_ID, transcriptic_run.id)
      except:
         datasets = self.api.datasets(BSL1_PROJECT_ID, transcriptic_run.id)
      
      flow_datasets = list(filter(lambda name: 'flow' in name,
                                 datasets.keys()))
      
      if not flow_datasets:
         return None
      
      flow_dataset_name = flow_datasets[0]
      
      flow_dataset = datasets[flow_dataset_name]
      
      temp_dir_path = tempfile.mkdtemp()
      fcs_file_path = os.path.join(temp_dir_path,'%s.fcs'%flow_dataset_name)
      
      #dataset_zipfile = self.api.get_zip(flow_dataset['id'])
      self.api.get_raw_file(flow_dataset['id'],fcs_file_path)
      
      #fcs_file = open(fcs_file_path,'wb')
      #fcs_file.write(dataset_fcs)
      #fcs_file.close()
      #
      #dataset_zipfile.extractall(temp_dir_path)
      
      #pass the temp file path to flow_analyze
      cell_count = get_cell_count(fcs_file_path, '%s_cells'%cell_line_name)
      
      shutil.rmtree(temp_dir_path)
      
      return cell_count
                  
                  
   def dequeue_runs(self, num_to_dequeue):
      #find the lowest priority number that have not been submitted that do not depend on incomplete runs
      independent_runs = Run.select().where(Run.submitted_at.is_null(True),
                                            Run.depends_on_run.is_null(True)
                                            )
      UpstreamRun = Run.alias()
      ready_dependent_runs = Run.select().join(UpstreamRun).where(Run.submitted_at.is_null(True),
                                                                  UpstreamRun.completed_at.is_null(False)
                                            )
      return (independent_runs | ready_dependent_runs).order_by(Run.priority.asc()).limit(num_to_dequeue)
      
      
   def submit_pending_runs(self, cell_line_containers):
      #find runs that are sitting in the queue (limit by the number of available extra plates)
      
      runs_to_submit = self.dequeue_runs(len(cell_line_containers))
   
      container_index = 0
   
      for run_to_submit in runs_to_submit:
         #update the input information for the run
         input_container = cell_line_containers[container_index]
         input_container.input_to_run = run_to_submit
         input_container.save()
   
         #submit the run
         self.submit_run(run_to_submit)
   
         container_index+=1
      
      
   def _kickoff_downstream_runs(self, upstream_run,input_params=None):
      """ Takes a non-terminal upstream run that just completed 
      and starts new runs from its output wellorcontainers """
      
      #how many containers (non-wells) are available for terminal experiments?
      
      output_containers = list(filter(lambda wellorcontainer: wellorcontainer.well_index is None,
                                      upstream_run.output_wellorcontainers))      
      
      if output_containers:         
         self.submit_pending_runs(output_containers)
         
      #submit a splitting experiment from the output well
         
      run = Run()
         
         
      run_params = {}
      run.protocol = Protocol.get_by_name('CellSplitting')
      run.priority = 1
      if self.max_splitting_plate_count:
         run_params.update({'max_plate_count':self.max_splitting_plate_count})
         
      if input_params:
         run_params.update(input_params)
         
      if run_params:
         run.input_json = json.dumps(run_params, indent=4)
      run.cell_line_name = upstream_run.cell_line_name
      run.save()     
      
      #link the output well of upstream to be the input to this downstream run
      input_well = upstream_run.output_wellorcontainers.where(WellOrContainer.well_index==0).get()
      input_well.input_to_run = run
      input_well.save()
      
      #requires some intelligence (likely needs its own function)
      new_transcriptic_run = self.submit_run(run)   
      
      #output wells (2 plates and 1 well)
      
      if new_transcriptic_run:
         #we skip the first plate because it was used for trypsonizing 
         for i in range(1,3):
            output_well = WellOrContainer.create_from_transcriptic_refs('replated_%s_cells_%s'%(run.cell_line_name,
                                                                                                i),
                                                        new_transcriptic_run['refs'])
            
            #we sometimes do fewer than 3 plates on splitting
            if not output_well:
               break
            
            output_well.output_of_run = run
            output_well.save()      

         output_well = WellOrContainer()
         
         #@TODO: update this to be a different well in the same container as the input well
         #@TODO: or find a way to dynamically pull from the experiment protocol's output wells
      
         def find_container(ref):
            
            if input_params and not input_params.get('flow_analyze',True):
               return ref['name'].startswith('trypsonized_%s_cells'%run.cell_line_name)
            else:
               return ref['name'].startswith('trypsonized_%s_cells'%run.cell_line_name) and \
                      ref['container_id']!=input_well.container_transcriptic_id               
         
         trx_output_well = list(filter(find_container,
                                       new_transcriptic_run['refs']))[0]
         
         output_well.container_transcriptic_id = trx_output_well['container_id']
         output_well.well_index = 0
         output_well.output_of_run = run
         output_well.save()
         
      
   def submit_run(self, run):
      """ Submit a local Run object to the transcriptic api """
      
      curr_time = datetime.datetime.now().strftime("%m_%d_%Y_%H_%M_%S")
      
      #pull the input container to submit to the protocol
      
      input_wellorcontainer = run.input_wellorcontainer.get()
      
      if run.protocol.is_terminal:
         
         parameters = {
            "cell_plate": input_wellorcontainer.container_transcriptic_id,
            'cells_per_ul': CELL_COUNT_OVERRIDE if CELL_COUNT_OVERRIDE else input_wellorcontainer.cells_per_ul,
            "test_mode": self.test_mode
         }
      else:
         parameters = {
            "trypsonized_cell_wells": [{
               "containerId": input_wellorcontainer.container_transcriptic_id,
               "wellIndex":  input_wellorcontainer.well_index
               }],
            'cells_per_ul': CELL_COUNT_OVERRIDE if CELL_COUNT_OVERRIDE else input_wellorcontainer.cells_per_ul,
            "test_mode": self.test_mode
         }
         
      if run.input_json:
         parameters.update(json.loads(run.input_json))


      run.input_json = json.dumps(parameters, indent=4)
      
      run.save()

      project_id = BSL1_PROJECT_ID if run.protocol.name in BSL1_PROTOCOLS else BSL2_PROJECT_ID

      run_title = run.cell_line_name.capitalize() + run.protocol.name + '_%s'%curr_time
      
      new_transcriptic_run, analysis_dict = self.api.submit_package_run(project_id, run.protocol.transcriptic_id,
                                                                       run_title, 
                                                                       parameters=parameters, 
                                                                       test_mode=self.test_mode,
                                                                       bsl=1 if project_id == BSL1_PROJECT_ID else 2)
      
      
      #we won't get a run if we are in analyze only mode
      if new_transcriptic_run:
         run.analysis_json = json.dumps(analysis_dict,indent=4)
         run.transcriptic_id = new_transcriptic_run['id']
         run.submitted_at = new_transcriptic_run['created_at']
         run.save()
         
         if run.protocol.initial_post:
            self.api.create_post(project_id,run.transcriptic_id,run.protocol.initial_post)
            
         if any([ref['container']['storage_condition'] in ['cold_80'] for ref in new_transcriptic_run['refs']]):
            self.api.create_post(project_id,run.transcriptic_id,'All tubes stored in -80C or liquid nitrogen long term should be screw cap')         
            
         if any([ref['name'].startswith('cryo') for ref in new_transcriptic_run['refs']]):
            self.api.create_post(project_id,run.transcriptic_id,'All containers prefixed with cryo should be stored in liquid nitrogen')
      
      return new_transcriptic_run
   
   @staticmethod
   def get_max_priority():
      max_priority_score = int(Run.select(fn.MAX(Run.priority)).where(Run.completed_at >> None).scalar())
      
      return 1 if not max_priority_score else max_priority_score
   
   def schedule_run_or_workflow(self, protocol_or_workflow_name, cell_line_name, input_json=None):
      """
      
      Schedule a future Transcritpic run or set of runs via a workflow. 
      
      """
      
      priority = self.get_max_priority()+1
      
      if any([member_info[0]==protocol_or_workflow_name for member_info in inspect.getmembers(workflow)]):
         current_workflow = getattr(workflow, protocol_or_workflow_name)(cell_line_name,
                                                                 priority,
                                                                 input_json = input_json)
         
         current_workflow.schedule_runs()
         
      else:
      
         #schedule single run
         with model.database_proxy.atomic() as txn:
            #create the run object
            
            run = Run(protocol = Protocol.get_by_name(protocol_or_workflow_name),
                      priority = priority,          
                      cell_line_name = cell_line_name,
                      input_json = json.dumps(input_json,indent=4) if input_json else None)
            
            run.save()        
         
   
   def init_thawing(self, transcriptic_run_id):
      """ Take a thawing job and store its information in our local database """
      
      with model.database_proxy.atomic() as txn:
         
         protocol = Protocol.get_by_name('CellThawing')
         transcriptic_run = transcriptic.objects.Run(transcriptic_run_id)
         transcriptic_launch = self.api.launch(protocol.transcriptic_id, transcriptic_run.attributes['launch_request_id'])  
         input_container_name, input_well_index = transcriptic_launch['inputs']['parameters']['cells_well'].split('/')


         container_info = transcriptic_launch['inputs']['refs'][input_container_name]
         input_container_id = container_info['id']
       
         cell_line_name = container_info['aliquots']["0"]['properties']['cell_line_name']
       
         run = Run()
      
         run.protocol = protocol
         run.transcriptic_id = transcriptic_run_id
         run.priority = 1
         run.cell_line_name = cell_line_name
         run.submitted_at = transcriptic_run.attributes['created_at']
      
         run.save()      
       
         #input well
       
         input_well = WellOrContainer()
         input_well.container_transcriptic_id = input_container_id
         input_well.well_index = int(input_well_index)
         input_well.input_to_run = run
         input_well.save()
         
         
         #output wells (1 well)
         
         output_well = WellOrContainer.create_from_transcriptic_refs('trypsonized_%s_cells'%cell_line_name,
                                                                     transcriptic_run.attributes['refs'])
         output_well.well_index = 0
         output_well.output_of_run = run
         output_well.save()   
      
   def execute_all_runs(self):
      if self.test_mode:
         self.api.execute_all_runs()
      
def main():
   
   parser = argparse.ArgumentParser()
   parser.add_argument('action',
                       default=None,
                       choices=['sync','schedule_run','run','init_thawing'])
   
   parser.add_argument('--test',action='store_true',
                       default=False,
                       dest='test_mode')   
   
   parser.add_argument('--analyze',action='store_true',
                       default=False,
                       dest='analyze_only')   
   
   parser.add_argument('--debug',action='store_true',
                          default=False,
                          dest='debug')  
   
    
   options, extra =parser.parse_known_args()
   
   setup_logging('logging.json' if not options.debug else 'debug_logging.json')   
   
   run_scheduler = RunScheduler(options.test_mode,
                                fake_get_cells_in_test_sample = 200*1000 if options.test_mode else None,
                                analyze_only = options.analyze_only)   
   
   init_db_connection('transcriptic_test' if options.test_mode else 'transcriptic_real')
   
   #make sure protoocls are up to date
   
   update_protocol_transcriptic_ids()
   
   if options.action=='sync':
      parser = argparse.ArgumentParser()
      parser.add_argument('--input', dest='input_json',default=None)      
      
      options, extra =parser.parse_known_args(extra)            
      input_params = json.loads(options.input_json) if options.input_json else None

      run_scheduler.sync(input_params = input_params)
      
      #test mode needs this to execute runs
      #this is done at the end to prevent a race condition between an executing run 
      #and a new run that is being made
      run_scheduler.execute_all_runs()
      
   elif options.action in ('schedule', 'schedule_run','run'):
      parser = argparse.ArgumentParser()
      parser.add_argument('protocol_name')
      parser.add_argument('cell_line_name')
      parser.add_argument('--input', dest='input_json',default=None)
      
      options, extra =parser.parse_known_args(extra)          
    
      input_json = json.loads(options.input_json) if options.input_json else None
      
      run_scheduler.schedule_run_or_workflow(options.protocol_name, options.cell_line_name,
                                             input_json)
   elif options.action=='init_thawing':
      
      parser = argparse.ArgumentParser()
      parser.add_argument('id')
      
      options, extra =parser.parse_known_args(extra)      
      run_scheduler.init_thawing(options.id)   

if __name__ == '__main__':
   main()  