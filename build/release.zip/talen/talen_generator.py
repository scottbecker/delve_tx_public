from __future__ import print_function

from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from Bio import Translate
standard_translator = Translate.unambiguous_dna_by_id[1]
my_protein = Seq("AVMGRWKGGRAAG", IUPAC.protein)
print(standard_translator.back_translate(my_protein))